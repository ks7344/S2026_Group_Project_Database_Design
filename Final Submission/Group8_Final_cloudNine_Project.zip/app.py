from flask import Flask, render_template, request, redirect, url_for
import os
import sqlite3

app = Flask(__name__)

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "c9_new.db")


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/")
def home():
    return render_template("index.html")


#===================================================================
#                   Reservations
#===================================================================

@app.route("/reservations")
def reservation_list():
    db = get_db()

    selected_status = request.args.get("status", "")
    search = request.args.get("search", "").strip()

    query = """
        SELECT
            r.reservationId,
            c.firstName || ' ' || c.lastName AS clientName,
            s.firstName || ' ' || s.lastName AS staffName,
            cr.cloudRegionName,
            r.requestStartTime,
            r.requestEndTime,
            r.reservationType,
            r.status,
            r.emergencyLevel
        FROM reservation r
        JOIN client c
            ON r.clientId = c.clientId
        JOIN staff s
            ON r.staffId = s.staffId
        LEFT JOIN cloud_region cr
            ON r.regionId = cr.regionId
        WHERE 1 = 1
    """

    params = []

    if selected_status:
        query += " AND r.status = ? "
        params.append(selected_status)

    if search:
        query += """
            AND (
                c.firstName LIKE ?
                OR c.lastName LIKE ?
                OR (c.firstName || ' ' || c.lastName) LIKE ?
                OR s.firstName LIKE ?
                OR s.lastName LIKE ?
                OR (s.firstName || ' ' || s.lastName) LIKE ?
                OR r.reservationType LIKE ?
                OR cr.cloudRegionName LIKE ?
            )
        """
        search_pattern = f"%{search}%"
        params.extend([
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern
        ])

    query += """
        ORDER BY r.requestStartTime DESC;
    """

    reservations = db.execute(query, params).fetchall()

    db.close()

    return render_template(
        "reservations.html",
        reservations=reservations,
        selected_status=selected_status
    )


@app.route("/reservations/<int:reservation_id>")
def reservation_detail(reservation_id):
    db = get_db()

    reservation = db.execute("""
        SELECT
            r.reservationId,
            c.firstName || ' ' || c.lastName AS clientName,
            c.email,
            s.firstName || ' ' || s.lastName AS staffName,
            cr.cloudRegionName,
            r.requestStartTime,
            r.requestEndTime,
            r.reservationType,
            r.status,
            r.emergencyLevel
        FROM reservation r
        JOIN client c
            ON r.clientId = c.clientId
        JOIN staff s
            ON r.staffId = s.staffId
        LEFT JOIN cloud_region cr
            ON r.regionId = cr.regionId
        WHERE r.reservationId = ?;
    """, (reservation_id,)).fetchone()

    needs = db.execute("""
        SELECT
            n.needId,
            rt.typeName,
            n.quantity,
            n.capacityRequirement,
            n.flexibilityLevel,
            n.note
        FROM need n
        JOIN resource_type rt
            ON n.resourceTypeId = rt.resourceTypeId
        WHERE n.reservationId = ?
        ORDER BY n.needId;
    """, (reservation_id,)).fetchall()

    assignments = db.execute("""
        SELECT
            aa.assignmentId,
            cr.cloudRegionName,
            aa.eventStartTime,
            aa.eventEndTime,
            aa.satisfactionScore,
            aa.reason
        FROM actual_assignment aa
        JOIN cloud_region cr
            ON aa.regionId = cr.regionId
        WHERE aa.reservationId = ?
        ORDER BY aa.eventStartTime DESC;
    """, (reservation_id,)).fetchall()

    deployment = db.execute("""
        SELECT
            d.deploymentId,
            d.deploymentName,
            ds.statusName,
            d.startTime,
            d.endTime
        FROM deployment d
        JOIN deployment_status ds
            ON d.statusId = ds.statusId
        WHERE d.reservationId = ?
        ORDER BY d.startTime DESC
        LIMIT 1;
    """, (reservation_id,)).fetchone()

    resource_types = db.execute("""
        SELECT
            resourceTypeId,
            typeName,
            performanceTier
        FROM resource_type
        ORDER BY typeName, performanceTier;
    """).fetchall()

    regions = db.execute("""
        SELECT
            regionId,
            cloudRegionName
        FROM cloud_region
        ORDER BY cloudRegionName;
    """).fetchall()

    db.close()

    return render_template(
        "reservation_detail.html",
        reservation=reservation,
        needs=needs,
        assignments=assignments,
        deployment=deployment,
        resource_types=resource_types,
        regions=regions
    )


@app.route("/reservations/<int:reservation_id>/status", methods=["POST"])
def update_reservation_status(reservation_id):
    new_status = request.form["status"]

    db = get_db()
    db.execute("""
        UPDATE reservation
        SET status = ?
        WHERE reservationId = ?;
    """, (new_status, reservation_id))

    db.commit()
    db.close()

    return redirect(url_for("reservation_detail", reservation_id=reservation_id))


@app.route("/reservations/<int:reservation_id>/needs", methods=["POST"])
def add_reservation_need(reservation_id):
    resource_type_id = request.form["resourceTypeId"]
    quantity = request.form["quantity"]
    capacity_requirement = request.form["capacityRequirement"]
    flexibility_level = request.form["flexibilityLevel"]
    note = request.form.get("note", "")

    db = get_db()
    db.execute("""
        INSERT INTO need (
            reservationId,
            resourceTypeId,
            quantity,
            capacityRequirement,
            flexibilityLevel,
            note
        )
        VALUES (?, ?, ?, ?, ?, ?);
    """, (
        reservation_id,
        resource_type_id,
        quantity,
        capacity_requirement,
        flexibility_level,
        note
    ))

    db.commit()
    db.close()

    return redirect(url_for("reservation_detail", reservation_id=reservation_id))


@app.route("/reservations/<int:reservation_id>/assignments", methods=["POST"])
def create_actual_assignment(reservation_id):
    region_id = request.form["regionId"]
    event_start_time = request.form["eventStartTime"]
    event_end_time = request.form["eventEndTime"]
    satisfaction_score = request.form.get("satisfactionScore") or None
    reason = request.form.get("reason", "")

    db = get_db()
    db.execute("""
        INSERT INTO actual_assignment (
            reservationId,
            regionId,
            eventStartTime,
            eventEndTime,
            satisfactionScore,
            reason
        )
        VALUES (?, ?, ?, ?, ?, ?);
    """, (
        reservation_id,
        region_id,
        event_start_time,
        event_end_time,
        satisfaction_score,
        reason
    ))

    db.commit()
    db.close()

    return redirect(url_for("reservation_detail", reservation_id=reservation_id))


@app.route("/reservations/<int:reservation_id>/edit", methods=["GET", "POST"])
def edit_reservation(reservation_id):
    db = get_db()

    if request.method == "POST":
        client_id = request.form["clientId"]
        staff_id = request.form["staffId"]
        region_id = request.form.get("regionId") or None
        request_start_time = request.form["requestStartTime"]
        request_end_time = request.form["requestEndTime"]
        reservation_type = request.form["reservationType"]
        status = request.form["status"]
        emergency_level = request.form["emergencyLevel"]

        db.execute("""
            UPDATE reservation
            SET
                clientId = ?,
                staffId = ?,
                regionId = ?,
                requestStartTime = ?,
                requestEndTime = ?,
                reservationType = ?,
                status = ?,
                emergencyLevel = ?
            WHERE reservationId = ?;
        """, (
            client_id,
            staff_id,
            region_id,
            request_start_time,
            request_end_time,
            reservation_type,
            status,
            emergency_level,
            reservation_id
        ))

        db.commit()
        db.close()

        return redirect(url_for("reservation_detail", reservation_id=reservation_id))

    reservation = db.execute("""
        SELECT
            reservationId,
            clientId,
            staffId,
            regionId,
            requestStartTime,
            requestEndTime,
            reservationType,
            status,
            emergencyLevel
        FROM reservation
        WHERE reservationId = ?;
    """, (reservation_id,)).fetchone()

    clients = db.execute("""
        SELECT
            clientId,
            firstName || ' ' || lastName AS clientName
        FROM client
        ORDER BY lastName, firstName;
    """).fetchall()

    staff_members = db.execute("""
        SELECT
            staffId,
            firstName || ' ' || lastName AS staffName,
            jobType
        FROM staff
        ORDER BY lastName, firstName;
    """).fetchall()

    regions = db.execute("""
        SELECT
            regionId,
            cloudRegionName
        FROM cloud_region
        ORDER BY cloudRegionName;
    """).fetchall()

    db.close()

    return render_template(
        "edit_reservation.html",
        reservation=reservation,
        clients=clients,
        staff_members=staff_members,
        regions=regions
    )


@app.route("/reservations/<int:reservation_id>/cancel", methods=["POST"])
def cancel_reservation(reservation_id):
    db = get_db()

    db.execute("""
        UPDATE reservation
        SET status = 'cancelled'
        WHERE reservationId = ?;
    """, (reservation_id,))

    db.commit()
    db.close()

    return redirect(url_for("reservation_list"))


@app.route("/reservations/create", methods=["GET", "POST"])
def create_reservation():
    db = get_db()

    if request.method == "POST":
        client_id = request.form["clientId"]
        staff_id = request.form["staffId"]
        region_id = request.form.get("regionId") or None
        request_start_time = request.form["requestStartTime"]
        request_end_time = request.form["requestEndTime"]
        reservation_type = request.form["reservationType"]
        status = request.form["status"]
        emergency_level = request.form["emergencyLevel"]

        db.execute("""
            INSERT INTO reservation (
                clientId,
                staffId,
                regionId,
                requestStartTime,
                requestEndTime,
                reservationType,
                status,
                emergencyLevel
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            client_id,
            staff_id,
            region_id,
            request_start_time,
            request_end_time,
            reservation_type,
            status,
            emergency_level
        ))

        db.commit()
        db.close()

        return redirect(url_for("reservation_list"))

    clients = db.execute("""
        SELECT
            clientId,
            firstName || ' ' || lastName AS clientName
        FROM client
        ORDER BY lastName, firstName;
    """).fetchall()

    staff_members = db.execute("""
        SELECT
            staffId,
            firstName || ' ' || lastName AS staffName,
            jobType
        FROM staff
        ORDER BY lastName, firstName;
    """).fetchall()

    regions = db.execute("""
        SELECT
            regionId,
            cloudRegionName
        FROM cloud_region
        ORDER BY cloudRegionName;
    """).fetchall()

    db.close()

    return render_template(
        "create_reservation.html",
        clients=clients,
        staff_members=staff_members,
        regions=regions
    )


@app.route("/clients/register", methods=["GET", "POST"])
def register_client():
    if request.method == "POST":
        first_name = request.form["firstName"]
        last_name = request.form["lastName"]
        client_type = request.form["clientType"]
        what_for = request.form.get("whatFor", "")
        email = request.form["email"]
        phone_number = request.form.get("phoneNumber", "")
        password = request.form["password"]

        db = get_db()
        db.execute("""
            INSERT INTO client (
                firstName,
                lastName,
                clientType,
                whatFor,
                email,
                phoneNumber,
                password
            )
            VALUES (?, ?, ?, ?, ?, ?, ?);
        """, (
            first_name,
            last_name,
            client_type,
            what_for,
            email,
            phone_number,
            password
        ))

        db.commit()
        db.close()

        return redirect(url_for("client_list"))

    return render_template("register_client.html")


@app.route("/clients")
def client_list():
    db = get_db()

    search = request.args.get("search", "").strip()

    base_query = """
        SELECT
            clientId,
            firstName || ' ' || lastName AS clientName,
            clientType,
            whatFor,
            email,
            phoneNumber
        FROM client
        WHERE 1 = 1
    """

    params = []

    if search:
        base_query += """
            AND (
                firstName LIKE ?
                OR lastName LIKE ?
                OR (firstName || ' ' || lastName) LIKE ?
                OR clientType LIKE ?
                OR whatFor LIKE ?
                OR email LIKE ?
                OR phoneNumber LIKE ?
            )
        """
        search_pattern = f"%{search}%"
        params.extend([
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern
        ])

    base_query += """
        ORDER BY clientId;
    """

    clients = db.execute(base_query, params).fetchall()

    db.close()

    return render_template(
        "clients.html",
        clients=clients,
        search=search
    )


@app.route("/clients/<int:client_id>/reservations")
def client_reservations(client_id):
    db = get_db()

    reservations = db.execute("""
        SELECT
            r.reservationId,
            c.firstName || ' ' || c.lastName AS clientName,
            s.firstName || ' ' || s.lastName AS staffName,
            cr.cloudRegionName,
            r.requestStartTime,
            r.requestEndTime,
            r.reservationType,
            r.status,
            r.emergencyLevel
        FROM reservation r
        JOIN client c
            ON r.clientId = c.clientId
        JOIN staff s
            ON r.staffId = s.staffId
        LEFT JOIN cloud_region cr
            ON r.regionId = cr.regionId
        WHERE r.clientId = ?
        ORDER BY r.requestStartTime DESC;
    """, (client_id,)).fetchall()

    db.close()

    return render_template(
        "reservations.html",
        reservations=reservations,
        selected_status=""
    )


@app.route("/reservation-assignments")
def reservation_assignments():
    db = get_db()

    assignments = db.execute("""
        SELECT
            aa.assignmentId,
            aa.reservationId,
            c.firstName || ' ' || c.lastName AS clientName,
            cr.cloudRegionName,
            aa.eventStartTime,
            aa.eventEndTime,
            aa.satisfactionScore,
            aa.reason
        FROM actual_assignment aa
        JOIN reservation r
            ON aa.reservationId = r.reservationId
        JOIN client c
            ON r.clientId = c.clientId
        JOIN cloud_region cr
            ON aa.regionId = cr.regionId
        ORDER BY aa.eventStartTime DESC;
    """).fetchall()

    db.close()

    return render_template(
        "reservation_assignments.html",
        assignments=assignments
    )


#===================================================================
#                   Infrastructure
#===================================================================

@app.route("/infrastructure/regions")
def infrastructure_regions():
    db = get_db()

    regions = db.execute("""
        SELECT
            cr.regionId,
            cr.cloudRegionName,
            dc.dataCenterId,
            dc.dataCenterName,
            az.zoneId,
            az.zoneName,
            az.zoneStatus
        FROM cloud_region cr
        JOIN data_center dc
            ON cr.regionId = dc.cloudRegionId
        JOIN availability_zone az
            ON dc.dataCenterId = az.dataCenterId
        ORDER BY cr.cloudRegionName, dc.dataCenterName, az.zoneName;
    """).fetchall()

    db.close()

    return render_template(
        "infrastructure_regions.html",
        regions=regions
    )


@app.route("/infrastructure/resources")
def resource_list():
    db = get_db()

    selected_status = request.args.get("status", "")
    search = request.args.get("search", "").strip()

    query = """
        SELECT
            r.resourceId,
            r.resourceLabel,
            r.currentStatus,
            rt.typeName,
            rt.performanceTier,
            rt.capacityRating,
            az.zoneName,
            dc.dataCenterName,
            cr.cloudRegionName
        FROM resource r
        JOIN resource_type rt
            ON r.resourceTypeId = rt.resourceTypeId
        JOIN availability_zone az
            ON r.zoneId = az.zoneId
        JOIN data_center dc
            ON az.dataCenterId = dc.dataCenterId
        JOIN cloud_region cr
            ON dc.cloudRegionId = cr.regionId
        WHERE 1 = 1
    """

    params = []

    if selected_status:
        query += " AND r.currentStatus = ? "
        params.append(selected_status)

    if search:
        query += """
            AND (
                r.resourceLabel LIKE ?
                OR rt.typeName LIKE ?
                OR rt.performanceTier LIKE ?
                OR az.zoneName LIKE ?
                OR dc.dataCenterName LIKE ?
                OR cr.cloudRegionName LIKE ?
            )
        """
        search_pattern = f"%{search}%"
        params.extend([
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern
        ])

    query += """
        ORDER BY r.resourceId;
    """

    resources = db.execute(query, params).fetchall()

    db.close()

    return render_template(
        "infrastructure_resources.html",
        resources=resources,
        selected_status=selected_status
    )


@app.route("/infrastructure/resources/<int:resource_id>")
def resource_detail(resource_id):
    db = get_db()

    resource = db.execute("""
        SELECT
            r.resourceId,
            r.resourceLabel,
            r.currentStatus,
            rt.typeName,
            rt.performanceTier,
            rt.capacityRating,
            az.zoneName,
            dc.dataCenterName,
            cr.cloudRegionName
        FROM resource r
        JOIN resource_type rt
            ON r.resourceTypeId = rt.resourceTypeId
        JOIN availability_zone az
            ON r.zoneId = az.zoneId
        JOIN data_center dc
            ON az.dataCenterId = dc.dataCenterId
        JOIN cloud_region cr
            ON dc.cloudRegionId = cr.regionId
        WHERE r.resourceId = ?;
    """, (resource_id,)).fetchone()

    capacities = db.execute("""
        SELECT
            capacityId,
            capacityName,
            capacityValue,
            capacityUnit
        FROM resource_capacity
        WHERE resourceId = ?
        ORDER BY capacityName;
    """, (resource_id,)).fetchall()

    events = db.execute("""
        SELECT
            availabilityEventId,
            eventType,
            startTime,
            endTime,
            note
        FROM resource_availability_event
        WHERE resourceId = ?
        ORDER BY startTime DESC;
    """, (resource_id,)).fetchall()

    db.close()

    return render_template(
        "infrastructure_resource_detail.html",
        resource=resource,
        capacities=capacities,
        events=events
    )


@app.route("/infrastructure/resources/create", methods=["GET", "POST"])
def create_resource():
    db = get_db()

    if request.method == "POST":
        resource_type_id = request.form["resourceTypeId"]
        zone_id = request.form["zoneId"]
        resource_label = request.form["resourceLabel"]
        current_status = request.form["currentStatus"]

        db.execute("""
            INSERT INTO resource (
                resourceTypeId,
                zoneId,
                resourceLabel,
                currentStatus
            )
            VALUES (?, ?, ?, ?);
        """, (
            resource_type_id,
            zone_id,
            resource_label,
            current_status
        ))

        db.commit()
        db.close()

        return redirect(url_for("resource_list"))

    resource_types = db.execute("""
        SELECT
            resourceTypeId,
            typeName,
            performanceTier
        FROM resource_type
        ORDER BY typeName, performanceTier;
    """).fetchall()

    zones = db.execute("""
        SELECT
            az.zoneId,
            az.zoneName,
            dc.dataCenterName,
            cr.cloudRegionName
        FROM availability_zone az
        JOIN data_center dc
            ON az.dataCenterId = dc.dataCenterId
        JOIN cloud_region cr
            ON dc.cloudRegionId = cr.regionId
        ORDER BY cr.cloudRegionName, dc.dataCenterName, az.zoneName;
    """).fetchall()

    db.close()

    return render_template(
        "create_resource.html",
        resource_types=resource_types,
        zones=zones
    )


@app.route("/infrastructure/resources/<int:resource_id>/edit", methods=["GET", "POST"])
def edit_resource(resource_id):
    db = get_db()

    if request.method == "POST":
        resource_type_id = request.form["resourceTypeId"]
        zone_id = request.form["zoneId"]
        resource_label = request.form["resourceLabel"]
        current_status = request.form["currentStatus"]

        db.execute("""
            UPDATE resource
            SET
                resourceTypeId = ?,
                zoneId = ?,
                resourceLabel = ?,
                currentStatus = ?
            WHERE resourceId = ?;
        """, (
            resource_type_id,
            zone_id,
            resource_label,
            current_status,
            resource_id
        ))

        db.commit()
        db.close()

        return redirect(url_for("resource_detail", resource_id=resource_id))

    resource = db.execute("""
        SELECT
            resourceId,
            resourceTypeId,
            zoneId,
            resourceLabel,
            currentStatus
        FROM resource
        WHERE resourceId = ?;
    """, (resource_id,)).fetchone()

    resource_types = db.execute("""
        SELECT
            resourceTypeId,
            typeName,
            performanceTier
        FROM resource_type
        ORDER BY typeName, performanceTier;
    """).fetchall()

    zones = db.execute("""
        SELECT
            az.zoneId,
            az.zoneName,
            dc.dataCenterName,
            cr.cloudRegionName
        FROM availability_zone az
        JOIN data_center dc
            ON az.dataCenterId = dc.dataCenterId
        JOIN cloud_region cr
            ON dc.cloudRegionId = cr.regionId
        ORDER BY cr.cloudRegionName, dc.dataCenterName, az.zoneName;
    """).fetchall()

    db.close()

    return render_template(
        "edit_resource.html",
        resource=resource,
        resource_types=resource_types,
        zones=zones
    )


@app.route("/infrastructure/resources/<int:resource_id>/retire", methods=["POST"])
def retire_resource(resource_id):
    db = get_db()

    db.execute("""
        UPDATE resource
        SET currentStatus = 'retired'
        WHERE resourceId = ?;
    """, (resource_id,))

    db.commit()
    db.close()

    return redirect(url_for("resource_list"))


@app.route("/infrastructure/resources/<int:resource_id>/capacities", methods=["POST"])
def add_resource_capacity(resource_id):
    capacity_name = request.form["capacityName"]
    capacity_value = request.form["capacityValue"]
    capacity_unit = request.form["capacityUnit"]

    db = get_db()

    db.execute("""
        INSERT INTO resource_capacity (
            resourceId,
            capacityName,
            capacityValue,
            capacityUnit
        )
        VALUES (?, ?, ?, ?);
    """, (
        resource_id,
        capacity_name,
        capacity_value,
        capacity_unit
    ))

    db.commit()
    db.close()

    return redirect(url_for("resource_detail", resource_id=resource_id))


@app.route("/infrastructure/capacities/<int:capacity_id>/delete", methods=["POST"])
def delete_resource_capacity(capacity_id):
    db = get_db()

    row = db.execute("""
        SELECT resourceId
        FROM resource_capacity
        WHERE capacityId = ?;
    """, (capacity_id,)).fetchone()

    if row:
        resource_id = row["resourceId"]

        db.execute("""
            DELETE FROM resource_capacity
            WHERE capacityId = ?;
        """, (capacity_id,))

        db.commit()
        db.close()

        return redirect(url_for("resource_detail", resource_id=resource_id))

    db.close()

    return redirect(url_for("resource_list"))


@app.route("/infrastructure/availability-events/create", methods=["GET", "POST"])
def create_availability_event():
    db = get_db()

    if request.method == "POST":
        resource_id = request.form["resourceId"]
        event_type = request.form["eventType"]
        start_time = request.form["startTime"]
        end_time = request.form.get("endTime") or None
        note = request.form.get("note", "")

        db.execute("""
            INSERT INTO resource_availability_event (
                resourceId,
                eventType,
                startTime,
                endTime,
                note
            )
            VALUES (?, ?, ?, ?, ?);
        """, (
            resource_id,
            event_type,
            start_time,
            end_time,
            note
        ))

        db.commit()
        db.close()

        return redirect(url_for("infrastructure_availability_events"))

    resources = db.execute("""
        SELECT
            resourceId,
            resourceLabel
        FROM resource
        ORDER BY resourceLabel;
    """).fetchall()

    db.close()

    return render_template(
        "create_availability_event.html",
        resources=resources
    )


@app.route("/infrastructure/availability-events/<int:event_id>/edit", methods=["GET", "POST"])
def edit_availability_event(event_id):
    db = get_db()

    if request.method == "POST":
        resource_id = request.form["resourceId"]
        event_type = request.form["eventType"]
        start_time = request.form["startTime"]
        end_time = request.form.get("endTime") or None
        note = request.form.get("note", "")

        db.execute("""
            UPDATE resource_availability_event
            SET
                resourceId = ?,
                eventType = ?,
                startTime = ?,
                endTime = ?,
                note = ?
            WHERE availabilityEventId = ?;
        """, (
            resource_id,
            event_type,
            start_time,
            end_time,
            note,
            event_id
        ))

        db.commit()
        db.close()

        return redirect(url_for("infrastructure_availability_events"))

    event = db.execute("""
        SELECT
            availabilityEventId,
            resourceId,
            eventType,
            startTime,
            endTime,
            note
        FROM resource_availability_event
        WHERE availabilityEventId = ?;
    """, (event_id,)).fetchone()

    resources = db.execute("""
        SELECT
            resourceId,
            resourceLabel
        FROM resource
        ORDER BY resourceLabel;
    """).fetchall()

    db.close()

    return render_template(
        "edit_availability_event.html",
        event=event,
        resources=resources
    )


@app.route("/infrastructure/availability-events/<int:event_id>/delete", methods=["POST"])
def delete_availability_event(event_id):
    db = get_db()

    db.execute("""
        DELETE FROM resource_availability_event
        WHERE availabilityEventId = ?;
    """, (event_id,))

    db.commit()
    db.close()

    return redirect(url_for("infrastructure_availability_events"))


@app.route("/infrastructure/availability-events")
def infrastructure_availability_events():
    db = get_db()

    events = db.execute("""
        SELECT
            rae.availabilityEventId,
            rae.resourceId,
            r.resourceLabel,
            rae.eventType,
            rae.startTime,
            rae.endTime,
            rae.note
        FROM resource_availability_event rae
        JOIN resource r
            ON rae.resourceId = r.resourceId
        ORDER BY rae.startTime DESC;
    """).fetchall()

    db.close()

    return render_template(
        "infrastructure_availability_events.html",
        events=events
    )


#===================================================================
#                   Deployments
#===================================================================


@app.route("/deployments")
def deployments():
    db = get_db()

    search = request.args.get("search", "").strip()
    status = request.args.get("status", "All")

    statuses = db.execute("""
        SELECT
            statusId,
            statusName
        FROM deployment_status
        ORDER BY statusId;
    """).fetchall()

    query = """
        SELECT
            d.deploymentId,
            d.deploymentName,
            d.reservationId,
            d.startTime,
            d.endTime,
            ds.statusName,
            c.firstName || ' ' || c.lastName AS clientName,
            current_priority.priorityName,
            COUNT(DISTINCT dr.resourceId) AS resourceCount,
            COALESCE(SUM(ur.quantity), 0) AS totalUsage
        FROM deployment d
        JOIN deployment_status ds
            ON d.statusId = ds.statusId
        LEFT JOIN reservation r
            ON d.reservationId = r.reservationId
        LEFT JOIN client c
            ON r.clientId = c.clientId
        LEFT JOIN deployment_resource dr
            ON d.deploymentId = dr.deploymentId
        LEFT JOIN usage_record ur
            ON d.deploymentId = ur.deploymentId
        LEFT JOIN (
            SELECT
                dph.deploymentId,
                pl.priorityName
            FROM deployment_priority_history dph
            JOIN priority_level pl
                ON dph.priorityLevelId = pl.priorityLevelId
            WHERE dph.endTime IS NULL
        ) AS current_priority
            ON d.deploymentId = current_priority.deploymentId
        WHERE 1 = 1
    """

    params = []

    if search:
        query += """
            AND (
                d.deploymentName LIKE ?
                OR c.firstName LIKE ?
                OR c.lastName LIKE ?
                OR (c.firstName || ' ' || c.lastName) LIKE ?
            )
        """
        search_pattern = f"%{search}%"
        params.extend([
            search_pattern,
            search_pattern,
            search_pattern,
            search_pattern
        ])

    if status != "All":
        query += " AND d.statusId = ? "
        params.append(status)

    query += """
        GROUP BY
            d.deploymentId,
            d.deploymentName,
            d.reservationId,
            d.startTime,
            d.endTime,
            ds.statusName,
            c.firstName,
            c.lastName,
            current_priority.priorityName
        ORDER BY d.startTime DESC;
    """

    deployment_rows = db.execute(query, params).fetchall()

    total_deployments = db.execute("""
        SELECT COUNT(*) AS count
        FROM deployment;
    """).fetchone()["count"]

    active_deployments = db.execute("""
        SELECT COUNT(*) AS count
        FROM deployment d
        JOIN deployment_status ds
            ON d.statusId = ds.statusId
        WHERE LOWER(ds.statusName) = 'active';
    """).fetchone()["count"]

    total_resources = db.execute("""
        SELECT COUNT(*) AS count
        FROM deployment_resource;
    """).fetchone()["count"]

    total_usage = db.execute("""
        SELECT COALESCE(SUM(quantity), 0) AS total
        FROM usage_record;
    """).fetchone()["total"]

    db.close()

    return render_template(
        "deployments.html",
        deployments=deployment_rows,
        statuses=statuses,
        total_deployments=total_deployments,
        active_deployments=active_deployments,
        total_resources=total_resources,
        total_usage=total_usage
    )


@app.route("/deployments/create", methods=["GET", "POST"])
def create_deployment():
    db = get_db()

    if request.method == "POST":

        deployment_name = request.form["deploymentName"]
        reservation_id = request.form.get("reservationId") or None
        status_id = request.form["statusId"]
        start_time = request.form["startTime"]
        end_time = request.form.get("endTime") or None

        db.execute("""
            INSERT INTO deployment (
                deploymentName,
                reservationId,
                statusId,
                startTime,
                endTime
            )
            VALUES (?, ?, ?, ?, ?);
        """, (
            deployment_name,
            reservation_id,
            status_id,
            start_time,
            end_time
        ))

        db.commit()
        db.close()

        return redirect(url_for("deployments"))

    reservations = db.execute("""
        SELECT
            r.reservationId,
            c.firstName || ' ' || c.lastName AS clientName
        FROM reservation r
        JOIN client c
            ON r.clientId = c.clientId
        ORDER BY r.reservationId;
    """).fetchall()

    statuses = db.execute("""
        SELECT
            statusId,
            statusName
        FROM deployment_status
        ORDER BY statusId;
    """).fetchall()

    db.close()

    return render_template(
        "create_deployment.html",
        reservations=reservations,
        statuses=statuses
    )


@app.route("/deployments/<int:deployment_id>")
def deployment_detail(deployment_id):
    db = get_db()

    deployment = db.execute("""
        SELECT
            d.deploymentId,
            d.deploymentName,
            d.reservationId,
            d.startTime,
            d.endTime,
            ds.statusName,
            c.firstName || ' ' || c.lastName AS clientName
        FROM deployment d
        JOIN deployment_status ds
            ON d.statusId = ds.statusId
        LEFT JOIN reservation r
            ON d.reservationId = r.reservationId
        LEFT JOIN client c
            ON r.clientId = c.clientId
        WHERE d.deploymentId = ?;
    """, (deployment_id,)).fetchone()

    priorities = db.execute("""
        SELECT
            pl.priorityName,
            pl.rankValue,
            dph.startTime,
            dph.endTime
        FROM deployment_priority_history dph
        JOIN priority_level pl
            ON dph.priorityLevelId = pl.priorityLevelId
        WHERE dph.deploymentId = ?
        ORDER BY dph.startTime DESC;
    """, (deployment_id,)).fetchall()

    resources = db.execute("""
        SELECT
            r.resourceLabel,
            rt.typeName,
            az.zoneName,
            r.currentStatus,
            dr.roleInDeployment,
            dr.assignedAt,
            dr.releasedAt
        FROM deployment_resource dr
        JOIN resource r
            ON dr.resourceId = r.resourceId
        JOIN resource_type rt
            ON r.resourceTypeId = rt.resourceTypeId
        JOIN availability_zone az
            ON r.zoneId = az.zoneId
        WHERE dr.deploymentId = ?
        ORDER BY dr.assignedAt DESC;
    """, (deployment_id,)).fetchall()

    usage = db.execute("""
        SELECT
            usageType,
            quantity,
            unit,
            startTime,
            endTime,
            isFinal
        FROM usage_record
        WHERE deploymentId = ?
        ORDER BY startTime DESC;
    """, (deployment_id,)).fetchall()

    events = db.execute("""
        SELECT
            eventType,
            eventTime,
            fromResourceId,
            toResourceId,
            reason,
            note AS notes
        FROM deployment_event
        WHERE deploymentId = ?
        ORDER BY eventTime DESC;
    """, (deployment_id,)).fetchall()

    db.close()

    return render_template(
        "deployment_detail.html",
        deployment=deployment,
        priorities=priorities,
        resources=resources,
        usage=usage,
        events=events
    )


@app.route("/deployments/<int:deployment_id>/edit", methods=["GET", "POST"])
def edit_deployment(deployment_id):
    db = get_db()

    if request.method == "POST":

        deployment_name = request.form["deploymentName"]
        reservation_id = request.form.get("reservationId") or None
        status_id = request.form["statusId"]
        start_time = request.form["startTime"]
        end_time = request.form.get("endTime") or None

        db.execute("""
            UPDATE deployment
            SET
                deploymentName = ?,
                reservationId = ?,
                statusId = ?,
                startTime = ?,
                endTime = ?
            WHERE deploymentId = ?;
        """, (
            deployment_name,
            reservation_id,
            status_id,
            start_time,
            end_time,
            deployment_id
        ))

        db.commit()
        db.close()

        return redirect(
            url_for(
                "deployment_detail",
                deployment_id=deployment_id
            )
        )

    deployment = db.execute("""
        SELECT
            deploymentId,
            deploymentName,
            reservationId,
            statusId,
            startTime,
            endTime
        FROM deployment
        WHERE deploymentId = ?;
    """, (deployment_id,)).fetchone()

    reservations = db.execute("""
        SELECT
            r.reservationId,
            c.firstName || ' ' || c.lastName AS clientName
        FROM reservation r
        JOIN client c
            ON r.clientId = c.clientId
        ORDER BY r.reservationId;
    """).fetchall()

    statuses = db.execute("""
        SELECT
            statusId,
            statusName
        FROM deployment_status
        ORDER BY statusId;
    """).fetchall()

    db.close()

    return render_template(
        "edit_deployment.html",
        deployment=deployment,
        reservations=reservations,
        statuses=statuses
    )


@app.route("/deployments/<int:deployment_id>/cancel", methods=["POST"])
def cancel_deployment(deployment_id):
    db = get_db()

    cancelled_status = db.execute("""
        SELECT statusId
        FROM deployment_status
        WHERE LOWER(statusName) = 'cancelled'
           OR LOWER(statusName) = 'canceled'
        LIMIT 1;
    """).fetchone()

    if cancelled_status:

        db.execute("""
            UPDATE deployment
            SET statusId = ?
            WHERE deploymentId = ?;
        """, (
            cancelled_status["statusId"],
            deployment_id
        ))

    else:

        db.execute("""
            UPDATE deployment
            SET endTime = datetime('now')
            WHERE deploymentId = ?;
        """, (deployment_id,))

    db.commit()
    db.close()

    return redirect(url_for("deployments"))


@app.route("/deployments/report")
def deployment_report():
    db = get_db()

    total_deployments = db.execute("""
        SELECT COUNT(*) AS count
        FROM deployment;
    """).fetchone()["count"]

    active_deployments = db.execute("""
        SELECT COUNT(*) AS count
        FROM deployment d
        JOIN deployment_status ds
            ON d.statusId = ds.statusId
        WHERE LOWER(ds.statusName) = 'active';
    """).fetchone()["count"]

    total_usage = db.execute("""
        SELECT COALESCE(SUM(quantity), 0) AS total
        FROM usage_record;
    """).fetchone()["total"]

    avg_usage = db.execute("""
        SELECT COALESCE(ROUND(AVG(deployment_usage.totalUsage), 2), 0) AS avgUsage
        FROM (
            SELECT
                d.deploymentId,
                COALESCE(SUM(ur.quantity), 0) AS totalUsage
            FROM deployment d
            LEFT JOIN usage_record ur
                ON d.deploymentId = ur.deploymentId
            GROUP BY d.deploymentId
        ) AS deployment_usage;
    """).fetchone()["avgUsage"]

    status_summary = db.execute("""
        SELECT
            ds.statusName,
            COUNT(d.deploymentId) AS count
        FROM deployment_status ds
        LEFT JOIN deployment d
            ON ds.statusId = d.statusId
        GROUP BY ds.statusId, ds.statusName
        ORDER BY count DESC;
    """).fetchall()

    priority_summary = db.execute("""
        SELECT
            pl.priorityName,
            COUNT(dph.deploymentId) AS count
        FROM priority_level pl
        LEFT JOIN deployment_priority_history dph
            ON pl.priorityLevelId = dph.priorityLevelId
        GROUP BY pl.priorityLevelId, pl.priorityName
        ORDER BY count DESC;
    """).fetchall()

    usage_summary = db.execute("""
        SELECT
            usageType,
            COALESCE(SUM(quantity), 0) AS total,
            unit
        FROM usage_record
        GROUP BY usageType, unit
        ORDER BY total DESC;
    """).fetchall()

    top_deployments = db.execute("""
        SELECT
            d.deploymentName,
            COALESCE(SUM(ur.quantity), 0) AS totalUsage
        FROM deployment d
        LEFT JOIN usage_record ur
            ON d.deploymentId = ur.deploymentId
        GROUP BY d.deploymentId, d.deploymentName
        ORDER BY totalUsage DESC
        LIMIT 5;
    """).fetchall()

    recent_events = db.execute("""
        SELECT
            d.deploymentName,
            de.eventType,
            de.eventTime,
            de.reason
        FROM deployment_event de
        JOIN deployment d
            ON de.deploymentId = d.deploymentId
        ORDER BY de.eventTime DESC
        LIMIT 10;
    """).fetchall()

    db.close()

    return render_template(
        "deployment_report.html",
        total_deployments=total_deployments,
        active_deployments=active_deployments,
        total_usage=total_usage,
        avg_usage=avg_usage,
        status_summary=status_summary,
        priority_summary=priority_summary,
        usage_summary=usage_summary,
        top_deployments=top_deployments,
        recent_events=recent_events
    )
#===================================================================
#                   Billing
#===================================================================
@app.route("/billing/adjustments")
def view_adjustments():

    show_inactive = request.args.get("show_inactive")

    conn = get_db()

    query = """
        SELECT
            ba.adjustmentId,
            ba.billId,
            ba.deposit,
            ba.depositDueDate,
            ba.accountCredit,
            ba.refund,
            ba.surcharge,
            ba.emergencyFee,
            ba.discount,
            ba.approvedByStaffId,
            ba.createdAt,
            ba.adjustmentStatus,
            bh.billStatus
        FROM bill_adjustment ba
        JOIN bill_header bh
            ON ba.billId = bh.billId
    """

    if show_inactive != "1":
        query += """
            WHERE ba.adjustmentStatus = 'active'
        """

    query += """
        ORDER BY ba.adjustmentId;
    """

    adjustments = conn.execute(query).fetchall()

    conn.close()

    return render_template(
        "billing_adjustments.html",
        adjustments=adjustments,
        show_inactive=show_inactive
    )


@app.route("/billing/adjustments/create", methods=["GET", "POST"])
def create_adjustment():

    conn = get_db()

    bills = conn.execute("""
        SELECT billId
        FROM bill_header
        ORDER BY billId;
    """).fetchall()

    if request.method == "POST":

        bill_id = request.form.get("billId", type=int)

        bill_exists = conn.execute("""
            SELECT billId
            FROM bill_header
            WHERE billId = ?
        """, (bill_id,)).fetchone()

        if not bill_exists:

            conn.close()

            return render_template(
                "error.html",
                error="Bill does not exist."
            )

        deposit = request.form.get("deposit", type=float) or 0
        deposit_due_date = request.form.get("depositDueDate")
        account_credit = request.form.get("accountCredit", type=float) or 0
        refund = request.form.get("refund", type=float) or 0
        surcharge = request.form.get("surcharge", type=float) or 0
        emergency_fee = request.form.get("emergencyFee", type=float) or 0
        discount = request.form.get("discount", type=float) or 0
        approved_by_staff_id = request.form.get(
            "approvedByStaffId",
            type=int
        )

        conn.execute("""
            INSERT INTO bill_adjustment (
                billId,
                deposit,
                depositDueDate,
                accountCredit,
                refund,
                surcharge,
                emergencyFee,
                discount,
                approvedByStaffId,
                adjustmentStatus
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
        """, (
            bill_id,
            deposit,
            deposit_due_date,
            account_credit,
            refund,
            surcharge,
            emergency_fee,
            discount,
            approved_by_staff_id
        ))

        conn.commit()
        conn.close()

        return redirect(url_for("view_adjustments"))

    conn.close()

    return render_template(
        "create_adjustment.html",
        bills=bills
    )

@app.route("/billing/adjustments/edit/<int:adjustment_id>", methods=["GET", "POST"])
def edit_adjustment(adjustment_id):

    conn = get_db()

    adjustment = conn.execute("""
        SELECT *
        FROM bill_adjustment
        WHERE adjustmentId = ?
    """, (adjustment_id,)).fetchone()

    if not adjustment:

        conn.close()

        return render_template(
            "error.html",
            error="Adjustment not found."
        )

    bills = conn.execute("""
        SELECT billId
        FROM bill_header
        ORDER BY billId;
    """).fetchall()

    if request.method == "POST":

        bill_id = request.form.get("billId", type=int)

        bill_exists = conn.execute("""
            SELECT billId
            FROM bill_header
            WHERE billId = ?
        """, (bill_id,)).fetchone()

        if not bill_exists:

            conn.close()

            return render_template(
                "error.html",
                error="Bill does not exist."
            )

        deposit = request.form.get("deposit", type=float) or 0
        deposit_due_date = request.form.get("depositDueDate")
        account_credit = request.form.get("accountCredit", type=float) or 0
        refund = request.form.get("refund", type=float) or 0
        surcharge = request.form.get("surcharge", type=float) or 0
        emergency_fee = request.form.get("emergencyFee", type=float) or 0
        discount = request.form.get("discount", type=float) or 0
        approved_by_staff_id = request.form.get(
            "approvedByStaffId",
            type=int
        )

        # OLD VERSION BECOMES INACTIVE

        conn.execute("""
            UPDATE bill_adjustment
            SET adjustmentStatus = 'inactive'
            WHERE adjustmentId = ?
        """, (adjustment_id,))

        # CREATE NEW ACTIVE VERSION

        conn.execute("""
            INSERT INTO bill_adjustment (
                billId,
                deposit,
                depositDueDate,
                accountCredit,
                refund,
                surcharge,
                emergencyFee,
                discount,
                approvedByStaffId,
                adjustmentStatus
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
        """, (
            bill_id,
            deposit,
            deposit_due_date,
            account_credit,
            refund,
            surcharge,
            emergency_fee,
            discount,
            approved_by_staff_id
        ))

        conn.commit()
        conn.close()

        return redirect(url_for("view_adjustments"))

    conn.close()

    return render_template(
        "edit_adjustment.html",
        adjustment=adjustment,
        bills=bills
    )

@app.route(
    "/billing/adjustments/delete/<int:adjustment_id>",
    methods=["POST"]
)
def delete_adjustment_crud(adjustment_id):

    conn = get_db()

    adjustment = conn.execute("""
        SELECT *
        FROM bill_adjustment
        WHERE adjustmentId = ?
    """, (adjustment_id,)).fetchone()

    if not adjustment:

        conn.close()

        return render_template(
            "error.html",
            error="Adjustment not found."
        )

    new_status = "inactive"

    if adjustment["adjustmentStatus"] == "inactive":
        new_status = "active"

    conn.execute("""
        UPDATE bill_adjustment
        SET adjustmentStatus = ?
        WHERE adjustmentId = ?
    """, (
        new_status,
        adjustment_id
    ))

    conn.commit()
    conn.close()

    return redirect(
        url_for(
            "view_adjustments",
            show_inactive=1
        )
    )

@app.route("/billing/view", methods=["GET", "POST"])
def billing_view():

    conn = get_db()

    search_type = "status"
    search_value = "all"

    if request.method == "POST":
        search_type = request.form.get("search_type", "status")
        search_value = request.form.get(
            "search_value",
            "all"
        ).strip().lower()

    bills_query = """
        SELECT
            bh.billId,
            bh.billStatus,
            bh.issueDate,
            bh.dueDate,
            pp.partyName,
            c.firstName || ' ' || c.lastName AS clientName,
            b.beneficiaryName
        FROM bill_header bh
        JOIN paying_party pp
            ON bh.payingPartyId = pp.payingPartyId
        JOIN client c
            ON pp.clientId = c.clientId
        LEFT JOIN beneficiary_paying_party bpp
            ON pp.payingPartyId = bpp.payingPartyId
        LEFT JOIN beneficiary b
            ON bpp.beneficiaryId = b.beneficiaryId
        WHERE 1 = 1
    """

    params = []

    if search_type == "bill_id":
        bills_query += " AND bh.billId = ? "
        params.append(search_value)

    elif search_type == "client_id":
        bills_query += " AND c.clientId = ? "
        params.append(search_value)

    elif search_type == "beneficiary_id":
        bills_query += " AND b.beneficiaryId = ? "
        params.append(search_value)

    elif search_type == "status":
        if search_value != "all":
            bills_query += """
                AND LOWER(bh.billStatus) = LOWER(?)
            """
            params.append(search_value)

    bills_query += """
        GROUP BY bh.billId
        ORDER BY bh.billId;
    """

    bills_raw = conn.execute(
        bills_query,
        params
    ).fetchall()

    bills = []

    total_bill_items = 0
    total_adjustments = 0

    for row in bills_raw:

        bill_id = row["billId"]

        items = conn.execute("""
            SELECT
                bi.billItemId,
                ur.usageType,
                ur.quantity,
                ur.unit,
                ur.startTime,
                ur.endTime,
                pr.unitPriceAtBilling,
                (
                    ur.quantity * pr.unitPriceAtBilling
                ) AS lineTotal
            FROM bill_item bi
            JOIN usage_record ur
                ON bi.usageRecordId = ur.usageRecordId
            JOIN pricing pr
                ON ur.usageRecordId = pr.usageRecordId
            WHERE bi.billId = ?
            ORDER BY bi.billItemId
        """, (bill_id,)).fetchall()

        bill_items_total = sum(
            (item["lineTotal"] or 0)
            for item in items
        )

        adjustment_row = conn.execute("""
            SELECT
                COALESCE(SUM(
                    COALESCE(deposit, 0)
                    + COALESCE(surcharge, 0)
                    + COALESCE(emergencyFee, 0)
                    - COALESCE(accountCredit, 0)
                    - COALESCE(refund, 0)
                    - COALESCE(discount, 0)
                ), 0) AS totalAdjustments
            FROM bill_adjustment
            WHERE billId = ?
            AND adjustmentStatus = 'active'
        """, (bill_id,)).fetchone()

        adjustments_total = (
            adjustment_row["totalAdjustments"] or 0
        )

        total_bill_items += bill_items_total
        total_adjustments += adjustments_total

        bill_dict = dict(row)

        bill_dict["items"] = items
        bill_dict["totalBillItems"] = bill_items_total
        bill_dict["totalAdjustments"] = adjustments_total

        bills.append(bill_dict)

    final_total = (
        total_bill_items + total_adjustments
    )

    payment_row = conn.execute("""
        SELECT
            COALESCE(SUM(amountPaid), 0)
            AS received_total
        FROM payment
    """).fetchone()

    received_total = (
        payment_row["received_total"] or 0
    )

    dashboard = {
        "total_bills": len(bills),
        "expected_total": final_total,
        "received_total": received_total,
        "unpaid_total": final_total - received_total
    }

    conn.close()

    return render_template(
        "billing_view.html",
        bills=bills,
        total_bill_items=total_bill_items,
        total_adjustments=total_adjustments,
        final_total=final_total,
        dashboard=dashboard
    )

@app.route("/billing/bill", methods=["GET", "POST"])
def billing_bill():
    conn = get_db()

    bills = []
    total_bill_items = 0
    total_adjustments = 0
    final_total = 0

    dashboard = {
        "expected_total": 0,
        "received_total": 0,
        "unpaid_total": 0
    }

    dashboard_data = conn.execute("""
    SELECT
        COALESCE((
            SELECT SUM(bill_totals.bill_total)
            FROM (
                SELECT
                    bh.billId,

                    COALESCE((
                        SELECT SUM(ur.quantity * pr.unitPriceAtBilling)
                        FROM bill_item bi
                        JOIN usage_record ur
                            ON bi.usageRecordId = ur.usageRecordId
                        JOIN pricing pr
                            ON ur.usageRecordId = pr.usageRecordId
                        WHERE bi.billId = bh.billId
                    ), 0)

                    +

                    COALESCE((
                        SELECT SUM(
                            COALESCE(ba.deposit, 0)
                            + COALESCE(ba.surcharge, 0)
                            + COALESCE(ba.emergencyFee, 0)
                            - COALESCE(ba.accountCredit, 0)
                            - COALESCE(ba.refund, 0)
                            - COALESCE(ba.discount, 0)
                        )
                        FROM bill_adjustment ba
                        WHERE ba.billId = bh.billId
                    ), 0) AS bill_total

                FROM bill_header bh
            ) AS bill_totals
        ), 0) AS expected_total,

        COALESCE((
            SELECT SUM(amountPaid)
            FROM payment
        ), 0) AS received_total
""").fetchone()

    dashboard["expected_total"] = dashboard_data["expected_total"] or 0
    dashboard["received_total"] = dashboard_data["received_total"] or 0
    dashboard["unpaid_total"] = (
        dashboard["expected_total"] - dashboard["received_total"]
    )

    if request.method == "POST":
        search_type = request.form["search_type"]
        search_value = request.form["search_value"].strip().lower()

        query = """
            SELECT
                bh.billId,
                bh.billStatus,
                bh.issueDate,
                bh.dueDate,
                pp.partyName,
                c.firstName || ' ' || c.lastName AS clientName,
                b.beneficiaryName,

                COALESCE((
                    SELECT SUM(ur.quantity * pr.unitPriceAtBilling)
                    FROM bill_item bi
                    JOIN usage_record ur
                        ON bi.usageRecordId = ur.usageRecordId
                    JOIN pricing pr
                        ON ur.usageRecordId = pr.usageRecordId
                    WHERE bi.billId = bh.billId
                ), 0) AS totalBillItems,

                COALESCE((
                    SELECT
                        SUM(
                            COALESCE(deposit, 0)
                            + COALESCE(surcharge, 0)
                            + COALESCE(emergencyFee, 0)
                            - COALESCE(accountCredit, 0)
                            - COALESCE(refund, 0)
                            - COALESCE(discount, 0)
                        )
                    FROM bill_adjustment ba
                    WHERE ba.billId = bh.billId
                ), 0) AS totalAdjustments

            FROM bill_header bh
            JOIN paying_party pp
                ON bh.payingPartyId = pp.payingPartyId
            JOIN client c
                ON pp.clientId = c.clientId
            LEFT JOIN beneficiary_paying_party bpp
                ON pp.payingPartyId = bpp.payingPartyId
            LEFT JOIN beneficiary b
                ON bpp.beneficiaryId = b.beneficiaryId
            WHERE 1 = 1
        """

        params = []

        if search_type == "bill_id":
            query += " AND bh.billId = ? "
            params.append(search_value)

        elif search_type == "client_id":
            query += " AND c.clientId = ? "
            params.append(search_value)

        elif search_type == "beneficiary_id":
            query += " AND b.beneficiaryId = ? "
            params.append(search_value)

        elif search_type == "status":
            if search_value != "all":
                query += " AND LOWER(bh.billStatus) = LOWER(?) "
                params.append(search_value)

        query += " ORDER BY bh.billId ASC; "

        bills_raw = conn.execute(query, params).fetchall()

        for row in bills_raw:
            bill_dict = dict(row)

            item_query = """
                SELECT
                    bi.billItemId,
                    ur.usageType,
                    ur.quantity,
                    ur.unit,
                    ur.startTime,
                    ur.endTime,
                    pr.unitPriceAtBilling,
                    (ur.quantity * pr.unitPriceAtBilling) AS lineTotal
                FROM bill_item bi
                JOIN usage_record ur
                    ON bi.usageRecordId = ur.usageRecordId
                JOIN pricing pr
                    ON ur.usageRecordId = pr.usageRecordId
                WHERE bi.billId = ?
                ORDER BY ur.startTime
            """

            items = conn.execute(
                item_query,
                (row["billId"],)
            ).fetchall()

            bill_dict["items"] = items
            bills.append(bill_dict)

        total_bill_items = sum(
            row["totalBillItems"] or 0 for row in bills
        )

        total_adjustments = sum(
            row["totalAdjustments"] or 0 for row in bills
        )

        final_total = total_bill_items + total_adjustments

    conn.close()

    return render_template(
        "billing_bill.html",
        bills=bills,
        total_bill_items=total_bill_items,
        total_adjustments=total_adjustments,
        final_total=final_total,
        dashboard=dashboard
    )

@app.route("/billing/bill/<int:bill_id>")
def billing_bill_detail(bill_id):

    conn = get_db()

    bill = conn.execute("""
        SELECT
            bh.billId,
            bh.billStatus,
            bh.issueDate,
            bh.dueDate,

            pp.payingPartyId,
            pp.partyName,

            c.clientId,
            c.firstName || ' ' || c.lastName
                AS clientName,
            c.email,
            c.phoneNumber,
            c.clientType,

            b.beneficiaryId,
            b.beneficiaryName

        FROM bill_header bh

        JOIN paying_party pp
            ON bh.payingPartyId = pp.payingPartyId

        JOIN client c
            ON pp.clientId = c.clientId

        LEFT JOIN beneficiary_paying_party bpp
            ON pp.payingPartyId = bpp.payingPartyId

        LEFT JOIN beneficiary b
            ON bpp.beneficiaryId = b.beneficiaryId

        WHERE bh.billId = ?
    """, (bill_id,)).fetchone()

    if not bill:

        conn.close()

        return render_template(
            "error.html",
            error="Bill not found."
        )

    addresses = conn.execute("""
        SELECT *
        FROM billing_address
        WHERE payingPartyId = ?
        ORDER BY addressType
    """, (
        bill["payingPartyId"],
    )).fetchall()

    payment_methods = conn.execute("""
        SELECT *
        FROM payment_method
        WHERE payingPartyId = ?
        ORDER BY paymentMethodId
    """, (
        bill["payingPartyId"],
    )).fetchall()

    payments = conn.execute("""
        SELECT *
        FROM payment
        WHERE billId = ?
        ORDER BY paymentId
    """, (
        bill_id,
    )).fetchall()

    adjustments = conn.execute("""
        SELECT
            ba.*,
            s.firstName || ' ' || s.lastName
                AS approvedBy
        FROM bill_adjustment ba
        
        LEFT JOIN staff s
            ON ba.approvedByStaffId = s.staffId

        WHERE ba.billId = ?
        AND ba.adjustmentStatus = 'active'

        ORDER BY ba.adjustmentId
    """, (
        bill_id,
    )).fetchall()

    bill_items = conn.execute("""
        SELECT

            bi.billItemId,

            ur.usageRecordId,
            ur.usageType,
            ur.quantity,
            ur.unit,
            ur.startTime,
            ur.endTime,

            pr.unitPriceAtBilling,

            (
                ur.quantity
                * pr.unitPriceAtBilling
            ) AS lineTotal,

            d.deploymentId,
            d.deploymentName,

            ds.statusName,

            r.resourceId,
            r.resourceLabel,

            rt.typeName

        FROM bill_item bi

        JOIN usage_record ur
            ON bi.usageRecordId = ur.usageRecordId

        JOIN pricing pr
            ON ur.usageRecordId = pr.usageRecordId

        JOIN deployment d
            ON ur.deploymentId = d.deploymentId

        JOIN deployment_status ds
            ON d.statusId = ds.statusId

        JOIN resource r
            ON ur.resourceId = r.resourceId

        JOIN resource_type rt
            ON r.resourceTypeId = rt.resourceTypeId

        WHERE bi.billId = ?

        ORDER BY bi.billItemId
    """, (
        bill_id,
    )).fetchall()

    deployment_events = conn.execute("""
        SELECT
            de.*,
            s.firstName || ' ' || s.lastName
                AS staffName
        FROM deployment_event de

        LEFT JOIN staff s
            ON de.staffId = s.staffId

        WHERE de.deploymentId IN (

            SELECT DISTINCT ur.deploymentId

            FROM bill_item bi

            JOIN usage_record ur
                ON bi.usageRecordId = ur.usageRecordId

            WHERE bi.billId = ?
        )

        ORDER BY de.eventTime DESC
    """, (
        bill_id,
    )).fetchall()

    reservations = conn.execute("""
        SELECT DISTINCT

            res.reservationId,
            res.requestStartTime,
            res.requestEndTime,
            res.reservationType,
            res.status,
            res.emergencyLevel

        FROM reservation res

        JOIN deployment d
            ON res.reservationId = d.reservationId

        JOIN usage_record ur
            ON d.deploymentId = ur.deploymentId

        JOIN bill_item bi
            ON ur.usageRecordId = bi.usageRecordId

        WHERE bi.billId = ?
    """, (
        bill_id,
    )).fetchall()

    total_bill_items = sum(
        item["lineTotal"] or 0
        for item in bill_items
    )

    total_adjustments = sum(
        (
            (adj["deposit"] or 0)
            + (adj["surcharge"] or 0)
            + (adj["emergencyFee"] or 0)
            - (adj["accountCredit"] or 0)
            - (adj["refund"] or 0)
            - (adj["discount"] or 0)
        )
        for adj in adjustments
        if adj["adjustmentStatus"] == "active"
    )

    total_payments = sum(
        payment["amountPaid"] or 0
        for payment in payments
    )

    final_total = (
        total_bill_items
        + total_adjustments
    )

    remaining_balance = (
        final_total
        - total_payments
    )

    conn.close()

    return render_template(
        "billing_bill_detail.html",

        bill=bill,

        addresses=addresses,
        payment_methods=payment_methods,
        payments=payments,
        adjustments=adjustments,
        bill_items=bill_items,
        deployment_events=deployment_events,
        reservations=reservations,

        total_bill_items=total_bill_items,
        total_adjustments=total_adjustments,
        total_payments=total_payments,
        final_total=final_total,
        remaining_balance=remaining_balance
    )

if __name__ == "__main__":
    app.run(debug=True)
