 PRAGMA foreign_keys = ON;

DELETE FROM pricing;
DELETE FROM bill_adjustment;
DELETE FROM payment;
DELETE FROM bill_item;
DELETE FROM bill_header;
DELETE FROM beneficiary_paying_party;
DELETE FROM beneficiary;
DELETE FROM payment_method;
DELETE FROM billing_address;
DELETE FROM paying_party;

DELETE FROM usage_record;
DELETE FROM deployment_event;
DELETE FROM deployment_priority_history;
DELETE FROM deployment_resource;
DELETE FROM deployment;
DELETE FROM priority_level;
DELETE FROM deployment_status;

DELETE FROM actual_assignment;
DELETE FROM need;
DELETE FROM reservation;

DELETE FROM resource_availability_event;
DELETE FROM resource_capacity;
DELETE FROM resource;
DELETE FROM resource_type;
DELETE FROM availability_zone;
DELETE FROM data_center;
DELETE FROM cloud_region;

DELETE FROM staff;
DELETE FROM client;

-- Insert data for CloudNine final clean ERD-consistent schema.
-- The insert order follows foreign-key dependencies.

-- Client & Staff
INSERT INTO client (
    clientId,
    firstName,
    lastName,
    whatFor,
    email,
    password,
    phoneNumber,
    clientType
) VALUES
(1, 'Alice', 'Chen', 'analytics workloads', 'alice.chen@cloudnine.demo', 'alice123', '6461234567', 'individual'),
(2, 'Brian', 'Patel', 'backup storage project', 'brian.patel@cloudnine.demo', 'brian456', '3109876543', 'group'),
(3, 'GreenLeaf', 'Labs', 'internal testing and monitoring', 'ops@greenleaflabs.demo', 'green789', '2015551003', 'organization'),
(4, 'Sofia', 'Rivera', 'realtime app hosting', 'sofia.rivera@cloudnine.demo', 'sofia321', '2125552020', 'individual');

INSERT INTO staff (
    staffId,
    firstName,
    lastName,
    jobType
) VALUES
(1, 'Maya', 'Lopez', 'scheduler'),
(2, 'Ethan', 'Brooks', 'operations'),
(3, 'Nina', 'Park', 'support'),
(4, 'Owen', 'Kim', 'billing');

-- Infrastructure
INSERT INTO cloud_region (
    regionId,
    cloudRegionName
) VALUES
(1, 'us-east'),
(2, 'eu-central'),
(3, 'ap-south'),
(4, 'us-west');

INSERT INTO data_center (
    dataCenterId,
    cloudRegionId,
    dataCenterName
) VALUES
(1, 1, 'US East DC 1'),
(2, 1, 'US East DC 2'),
(3, 2, 'EU Central DC 1'),
(4, 3, 'AP South DC 1'),
(5, 4, 'US West DC 1'),
(6, 1, 'US East DC 3'),
    (7, 2, 'EU Central DC 2'),
    (8, 4, 'US West DC 2');

INSERT INTO availability_zone (
    zoneId,
    dataCenterId,
    zoneName,
    zoneStatus
) VALUES
(1, 1, 'us-east-1a', 'active'),
(2, 2, 'us-east-1b', 'active'),
(3, 3, 'eu-central-1a', 'active'),
(4, 4, 'ap-south-1a', 'degraded'),
(5, 5, 'us-west-1a', 'active'),
(6, 6, 'us-east-1c', 'active'),
    (7, 7, 'eu-central-1b', 'active'),
    (8, 8, 'us-west-1b', 'active');

INSERT INTO resource_type (
    resourceTypeId,
    typeName,
    performanceTier,
    capacityRating
) VALUES
(1, 'compute_vm', 'high', '16 vCPU'),
(2, 'storage_volume', 'standard', '2 TB'),
(3, 'backup_node', 'standard', '5 TB'),
(4, 'monitoring_node', 'enterprise', '10 Gbps'),
(5, 'gpu_instance', 'premium', '1 GPU / 32 GB VRAM');

INSERT INTO resource (
    resourceId,
    resourceTypeId,
    zoneId,
    resourceLabel,
    currentStatus
) VALUES
(101, 1, 1, 'comp-us-101', 'maintenance'),
(102, 2, 2, 'stor-us-102', 'available'),
(103, 3, 3, 'back-eu-103', 'in_use'),
(104, 1, 2, 'comp-us-104', 'in_use'),
(105, 4, 4, 'mon-ap-105', 'available'),
(106, 5, 5, 'gpu-west-106', 'available'),
(107, 1, 6, 'comp-us-107', 'available'),
    (108, 2, 6, 'stor-us-108', 'in_use'),
    (109, 5, 8, 'gpu-west-109', 'in_use'),
    (110, 4, 7, 'mon-eu-110', 'available'),
    (111, 3, 7, 'back-eu-111', 'maintenance'),
    (112, 1, 3, 'comp-eu-112', 'available'),
    (113, 2, 5, 'stor-west-113', 'available'),
    (114, 5, 4, 'gpu-ap-114', 'maintenance'),
    (115, 4, 1, 'mon-us-115', 'in_use'),
    (116, 3, 2, 'back-us-116', 'available');

INSERT INTO resource_capacity (
    capacityId,
    resourceId,
    capacityName,
    capacityValue,
    capacityUnit
) VALUES
(1, 101, 'cpu_cores', 16, 'cores'),
(2, 102, 'storage_space', 2000, 'GB'),
(3, 103, 'backup_space', 5000, 'GB'),
(4, 104, 'cpu_cores', 16, 'cores'),
(5, 105, 'network_bandwidth', 10, 'Gbps'),
(6, 106, 'gpu_memory', 32, 'GB'),
(7, 107, 'cpu_cores', 16, 'cores'),
    (8, 107, 'memory', 64, 'GB'),
    (9, 108, 'storage_space', 4000, 'GB'),
    (10, 108, 'iops', 12000, 'ops/sec'),
    (11, 109, 'gpu_count', 2, 'GPUs'),
    (12, 109, 'gpu_memory', 64, 'GB'),
    (13, 110, 'network_bandwidth', 10, 'Gbps'),
    (14, 110, 'metrics_retention', 90, 'days'),
    (15, 111, 'backup_space', 8000, 'GB'),
    (16, 111, 'snapshot_retention', 60, 'days'),
    (17, 112, 'cpu_cores', 32, 'cores'),
    (18, 112, 'memory', 128, 'GB'),
    (19, 113, 'storage_space', 3000, 'GB'),
    (20, 113, 'iops', 9000, 'ops/sec'),
    (21, 114, 'gpu_count', 1, 'GPU'),
    (22, 114, 'gpu_memory', 32, 'GB'),
    (23, 115, 'network_bandwidth', 20, 'Gbps'),
    (24, 115, 'metrics_retention', 120, 'days'),
    (25, 116, 'backup_space', 6000, 'GB'),
    (26, 116, 'snapshot_retention', 45, 'days');

INSERT INTO resource_availability_event (
    availabilityEventId,
    resourceId,
    eventType,
    startTime,
    endTime,
    note
) VALUES
(1, 101, 'maintenance', '2026-03-07 12:00:00', '2026-03-09 09:00:00', 'Scheduled maintenance that triggered workload migration'),
(2, 102, 'repair', '2026-02-20 10:00:00', '2026-02-20 18:00:00', 'Minor storage controller repair completed same day'),
(3, 105, 'outage', '2026-02-28 02:00:00', '2026-02-28 03:30:00', 'Short monitoring outage caused by network switch issue'),
(4, 106, 'maintenance', '2026-03-18 01:00:00', NULL, 'GPU driver upgrade in progress'),
(5, 107, 'maintenance', '2026-01-05 01:00:00', '2026-01-05 04:00:00', 'January kernel patch on US East compute host'),
    (6, 108, 'outage', '2026-01-22 11:15:00', '2026-01-22 12:05:00', 'Brief storage path interruption; redundancy preserved'),
    (7, 109, 'repair', '2026-01-28 02:00:00', '2026-01-28 06:30:00', 'GPU cooling fan replacement'),
    (8, 110, 'maintenance', '2026-02-03 00:30:00', '2026-02-03 02:00:00', 'Monitoring collector upgrade'),
    (9, 111, 'outage', '2026-02-14 03:40:00', '2026-02-14 05:10:00', 'Backup node network outage during switch failover'),
    (10, 112, 'maintenance', '2026-02-25 23:00:00', '2026-02-26 01:00:00', 'Hypervisor version update'),
    (11, 113, 'repair', '2026-03-04 08:00:00', '2026-03-04 10:30:00', 'Disk shelf inspection and cable replacement'),
    (12, 114, 'maintenance', '2026-03-21 01:00:00', '2026-03-21 05:30:00', 'GPU driver and CUDA image update'),
    (13, 115, 'outage', '2026-03-29 18:20:00', '2026-03-29 18:55:00', 'Metrics ingest delay caused by temporary network congestion'),
    (14, 116, 'maintenance', '2026-04-02 00:00:00', '2026-04-02 03:00:00', 'Monthly backup validation and index rebuild'),
    (15, 107, 'repair', '2026-04-09 13:00:00', '2026-04-09 15:00:00', 'Compute host memory module replacement'),
    (16, 108, 'maintenance', '2026-04-16 22:00:00', '2026-04-17 00:30:00', 'Storage firmware upgrade'),
    (17, 109, 'maintenance', '2026-04-20 01:00:00', '2026-04-20 04:00:00', 'GPU performance profile tuning'),
    (18, 111, 'repair', '2026-04-24 09:15:00', '2026-04-24 11:45:00', 'Backup disk replacement after warning alert'),
    (19, 112, 'outage', '2026-04-26 05:10:00', '2026-04-26 05:40:00', 'Brief compute control-plane interruption'),
    (20, 115, 'maintenance', '2026-04-30 23:00:00', NULL, 'Ongoing monitoring rules refresh');

-- Reservation & Scheduling
INSERT INTO reservation (
    reservationId,
    clientId,
    staffId,
    regionId,
    requestStartTime,
    requestEndTime,
    reservationType,
    status,
    emergencyLevel
) VALUES
(1, 1, 1, 1, '2026-03-01 08:00:00', '2026-03-10 18:00:00', 'analytics_cluster', 'completed', 3),
(2, 2, 2, 2, '2026-03-02 09:30:00', '2026-03-15 12:00:00', 'backup_rollout', 'active', 2),
(3, 1, 3, 1, '2026-03-03 07:00:00', '2026-03-12 20:00:00', 'fraud_detection', 'completed', 5),
(4, 3, 2, 3, '2026-03-05 10:00:00', '2026-03-08 16:30:00', 'internal_test', 'completed', 1),
(5, 4, 1, 4, '2026-03-18 09:00:00', '2026-03-25 17:00:00', 'gpu_app_hosting', 'planning', 4),
(6, 1, 1, 1, '2026-01-06 09:00:00', '2026-01-12 18:00:00', 'quarterly_analytics_batch', 'completed', 3),
    (7, 2, 2, 2, '2026-01-10 10:00:00', '2026-01-20 17:00:00', 'secure_backup_window', 'completed', 2),
    (8, 3, 3, 3, '2026-01-18 08:30:00', '2026-01-21 18:30:00', 'monitoring_validation', 'completed', 1),
    (9, 4, 1, 4, '2026-01-25 09:00:00', '2026-02-02 17:30:00', 'gpu_preview_hosting', 'completed', 4),
    (10, 2, 3, 1, '2026-01-28 12:00:00', '2026-02-03 12:00:00', 'temporary_compute_pool', 'cancelled', 2),

    (11, 1, 2, 1, '2026-02-04 08:00:00', '2026-02-11 18:00:00', 'model_training_compute', 'completed', 4),
    (12, 3, 1, 2, '2026-02-09 09:30:00', '2026-02-16 16:30:00', 'eu_monitoring_trial', 'completed', 2),
    (13, 4, 2, 4, '2026-02-15 11:00:00', '2026-02-23 19:00:00', 'west_app_scaling', 'completed', 3),
    (14, 2, 1, 2, '2026-02-21 07:00:00', '2026-03-01 12:00:00', 'backup_retention_extension', 'completed', 2),
    (15, 1, 3, 3, '2026-02-26 13:00:00', '2026-03-04 18:00:00', 'ap_south_test_burst', 'completed', 3),

    (16, 3, 2, 1, '2026-03-11 08:00:00', '2026-03-18 18:00:00', 'compliance_test_environment', 'completed', 2),
    (17, 4, 1, 4, '2026-03-20 09:00:00', '2026-03-30 20:00:00', 'gpu_inference_demo', 'completed', 4),
    (18, 2, 2, 2, '2026-03-24 10:30:00', '2026-04-02 15:00:00', 'cross_region_backup', 'completed', 3),
    (19, 1, 3, 1, '2026-03-28 06:00:00', '2026-04-05 21:00:00', 'fraud_model_retest', 'completed', 5),
    (20, 3, 1, 3, '2026-03-31 09:00:00', '2026-04-03 17:00:00', 'internal_monitoring_patch', 'completed', 1),

    (21, 4, 2, 4, '2026-04-05 10:00:00', '2026-04-15 18:00:00', 'customer_portal_scaleout', 'active', 4),
    (22, 1, 1, 1, '2026-04-08 09:00:00', '2026-04-22 18:00:00', 'analytics_refresh', 'active', 3),
    (23, 2, 3, 2, '2026-04-12 08:00:00', '2026-04-19 16:00:00', 'backup_rehearsal', 'completed', 2),
    (24, 3, 2, 3, '2026-04-18 11:00:00', '2026-04-25 17:30:00', 'ap_south_failover_test', 'completed', 3),
    (25, 4, 1, 4, '2026-04-24 09:00:00', '2026-05-03 20:00:00', 'gpu_realtime_app_hosting', 'planning', 5);

INSERT INTO need (
    needId,
    reservationId,
    resourceTypeId,
    quantity,
    capacityRequirement,
    flexibilityLevel,
    note
) VALUES
(1, 1, 1, 2, '16 vCPU each', 'strict', 'Main compute nodes for analytics run'),
(2, 1, 2, 1, 'at least 1 TB', 'strict', 'Shared storage for analytics data'),
(3, 2, 3, 1, 'minimum 5 TB', 'flexible', 'Backup storage can scale if demand grows'),
(4, 3, 1, 1, '16 vCPU and low latency', 'strict', 'Realtime detection service'),
(5, 4, 4, 1, 'basic monitoring coverage', 'flexible', 'Monitoring only for internal testing'),
(6, 5, 5, 1, 'single GPU instance', 'strict', 'GPU support for realtime application'),
(7, 6, 1, 2, '16 vCPU each', 'strict', 'Compute nodes for quarterly analytics batch'),
    (8, 6, 2, 1, '2 TB shared storage', 'flexible', 'Temporary analytics workspace'),
    (9, 7, 3, 1, '5 TB minimum backup capacity', 'strict', 'Secure backup target'),
    (10, 7, 2, 1, '1 TB staging volume', 'flexible', 'Staging area for backup verification'),
    (11, 8, 4, 1, '10 Gbps monitoring stream', 'strict', 'Monitoring validation node'),
    (12, 9, 5, 1, '1 GPU / 32 GB VRAM minimum', 'strict', 'GPU app preview environment'),
    (13, 9, 2, 1, '500 GB app storage', 'flexible', 'Application image and logs'),
    (14, 10, 1, 1, '16 vCPU compute pool', 'flexible', 'Cancelled by client before allocation'),

    (15, 11, 5, 1, '1 GPU / 32 GB VRAM', 'strict', 'Model training accelerator'),
    (16, 11, 1, 1, '16 vCPU orchestration host', 'flexible', 'Training control node'),
    (17, 12, 4, 1, 'enterprise monitoring node', 'strict', 'EU monitoring trial'),
    (18, 13, 1, 2, '16 vCPU each', 'strict', 'Scale-out app hosts'),
    (19, 13, 2, 1, '2 TB volume', 'flexible', 'Application data volume'),
    (20, 14, 3, 1, '5 TB backup retention', 'strict', 'Retention extension'),
    (21, 15, 1, 1, '16 vCPU burst compute', 'flexible', 'AP South testing burst'),

    (22, 16, 1, 1, '16 vCPU test environment', 'strict', 'Compliance environment'),
    (23, 16, 4, 1, 'monitoring coverage', 'flexible', 'Audit monitoring'),
    (24, 17, 5, 1, '1 GPU / 32 GB VRAM', 'strict', 'GPU inference demo'),
    (25, 18, 3, 1, '5 TB backup target', 'strict', 'Cross-region backup'),
    (26, 18, 2, 1, '1 TB transfer cache', 'flexible', 'Cache volume'),
    (27, 19, 1, 2, 'low-latency compute', 'strict', 'Fraud model retest'),
    (28, 20, 4, 1, 'basic monitoring coverage', 'flexible', 'Internal monitoring patch'),

    (29, 21, 1, 2, 'high availability app hosts', 'strict', 'Customer portal scale-out'),
    (30, 21, 2, 1, '2 TB application storage', 'flexible', 'Portal storage'),
    (31, 22, 1, 2, '16 vCPU each', 'strict', 'Analytics refresh compute'),
    (32, 22, 2, 1, '2 TB shared data volume', 'strict', 'Analytics refresh dataset'),
    (33, 23, 3, 1, '5 TB rehearsal backup', 'strict', 'Backup rehearsal target'),
    (34, 24, 4, 1, 'monitoring during failover', 'strict', 'AP South failover monitoring'),
    (35, 25, 5, 1, '1 GPU / 32 GB VRAM', 'strict', 'Realtime GPU app'),
    (36, 25, 2, 1, '1 TB app data', 'flexible', 'Data volume for realtime app');

INSERT INTO actual_assignment (
    assignmentId,
    reservationId,
    regionId,
    eventStartTime,
    eventEndTime,
    satisfactionScore,
    reason
) VALUES
(1, 1, 1, '2026-03-01 08:00:00', '2026-03-10 18:00:00', 4, 'Assigned to requested region and completed successfully'),
(2, 2, 2, '2026-03-02 09:30:00', NULL, 5, 'Backup capacity available in preferred region'),
(3, 3, 1, '2026-03-03 07:00:00', '2026-03-12 20:00:00', 4, 'Stayed in requested region after migration to another local resource'),
(4, 4, 3, '2026-03-05 10:00:00', '2026-03-08 16:30:00', 3, 'Used spare resources for internal testing'),
(5, 5, 4, '2026-03-18 09:00:00', NULL, NULL, 'Planned GPU assignment'),
(6, 6, 1, '2026-01-06 09:00:00', '2026-01-12 18:00:00', 4, 'Assigned to US East for lowest latency to analytics team'),
    (7, 7, 2, '2026-01-10 10:00:00', '2026-01-20 17:00:00', 5, 'EU Central had sufficient backup capacity'),
    (8, 8, 3, '2026-01-18 08:30:00', '2026-01-21 18:30:00', 3, 'AP South used for regional monitoring validation'),
    (9, 9, 4, '2026-01-25 09:00:00', '2026-02-02 17:30:00', 4, 'US West GPU capacity available for preview workload'),

    (10, 11, 4, '2026-02-04 08:00:00', '2026-02-11 18:00:00', 5, 'GPU workload assigned to US West after availability check'),
    (11, 12, 2, '2026-02-09 09:30:00', '2026-02-16 16:30:00', 4, 'EU Central matched client monitoring requirements'),
    (12, 13, 4, '2026-02-15 11:00:00', '2026-02-23 19:00:00', 4, 'US West provided best app scaling capacity'),
    (13, 14, 2, '2026-02-21 07:00:00', '2026-03-01 12:00:00', 5, 'Backup extension kept in EU Central'),
    (14, 15, 3, '2026-02-26 13:00:00', '2026-03-04 18:00:00', 3, 'AP South capacity available despite degraded zone warning'),

    (15, 16, 1, '2026-03-11 08:00:00', '2026-03-18 18:00:00', 4, 'US East compliance environment assigned successfully'),
    (16, 17, 4, '2026-03-20 09:00:00', '2026-03-30 20:00:00', 5, 'US West GPU matched inference demo requirements'),
    (17, 18, 2, '2026-03-24 10:30:00', '2026-04-02 15:00:00', 4, 'EU Central backup plus transfer cache assigned'),
    (18, 19, 1, '2026-03-28 06:00:00', '2026-04-05 21:00:00', 4, 'US East used for low-latency fraud model retest'),
    (19, 20, 3, '2026-03-31 09:00:00', '2026-04-03 17:00:00', 3, 'AP South monitoring assigned for internal test'),

    (20, 21, 4, '2026-04-05 10:00:00', NULL, NULL, 'Active portal scale-out assigned to US West'),
    (21, 22, 1, '2026-04-08 09:00:00', NULL, NULL, 'Active analytics refresh assigned to US East'),
    (22, 23, 2, '2026-04-12 08:00:00', '2026-04-19 16:00:00', 5, 'EU Central backup rehearsal completed'),
    (23, 24, 3, '2026-04-18 11:00:00', '2026-04-25 17:30:00', 4, 'AP South failover monitoring completed'),
    (24, 25, 4, '2026-04-24 09:00:00', NULL, NULL, 'Planning GPU realtime app assignment in US West');

-- Deployment & Usage
INSERT INTO deployment_status (
    statusId,
    statusName
) VALUES
(1, 'planned'),
(2, 'active'),
(3, 'completed'),
(4, 'paused'),
(5, 'cancelled');

INSERT INTO priority_level (
    priorityLevelId,
    priorityName,
    rankValue
) VALUES
(1, 'low', 1),
(2, 'medium', 2),
(3, 'high', 3),
(4, 'emergent', 4);

INSERT INTO deployment (
    deploymentId,
    reservationId,
    statusId,
    deploymentName,
    startTime,
    endTime
) VALUES
(1, 1, 3, 'North America Analytics Cluster', '2026-03-01 08:00:00', '2026-03-10 18:00:00'),
(2, 2, 2, 'EU Backup Storage Rollout', '2026-03-02 09:30:00', NULL),
(3, 3, 3, 'Realtime Fraud Detection Service', '2026-03-03 07:00:00', '2026-03-12 20:00:00'),
(4, 4, 3, 'Internal Test Environment', '2026-03-05 10:00:00', '2026-03-08 16:30:00'),
(5, 5, 1, 'US West GPU App Hosting', '2026-03-18 09:00:00', NULL),

(6, 21, 3, 'April Analytics Expansion', '2026-04-08 08:00:00', '2026-04-15 18:00:00'),
(7, 23, 3, 'April Backup Burst', '2026-04-11 09:00:00', '2026-04-13 21:00:00'),
(8, 22, 3, 'May Analytics Retraining', '2026-05-02 08:00:00', '2026-05-18 18:00:00'),
(9, 19, 3, 'May Fraud Detection Refresh', '2026-05-10 06:00:00', '2026-05-20 20:00:00'),
(10, 25, 2, 'June GPU Hosting', '2026-06-01 08:00:00', NULL),
(11, 18, 3, 'June Emergency Backup', '2026-06-14 10:00:00', '2026-06-16 22:00:00'),
(12, 22, 2, 'Four Month Analytics Retainer', '2026-04-01 08:00:00', '2026-07-31 18:00:00'),
(13, 23, 2, 'Patel Recurring Backup Service', '2026-04-01 09:00:00', '2026-07-31 23:00:00'),
(14, 25, 2, 'Sofia Long Term GPU Hosting', '2026-04-15 08:00:00', '2026-08-15 18:00:00'),
(15, 20, 3, 'GreenLeaf Monitoring Retainer', '2026-04-01 00:00:00', '2026-07-31 23:59:59'),
(16, 16, 2, 'GreenLeaf Support Coverage', '2026-05-01 00:00:00', '2026-08-31 23:59:59');

INSERT INTO deployment_resource (
    deploymentResourceId,
    deploymentId,
    resourceId,
    assignedAt,
    releasedAt,
    roleInDeployment,
    assignmentStatus
) VALUES
(1, 1, 101, '2026-03-01 08:00:00', '2026-03-07 14:20:00', 'primary_compute', 'released'),
(2, 1, 102, '2026-03-01 08:05:00', '2026-03-10 18:00:00', 'shared_storage', 'released'),
(3, 2, 103, '2026-03-02 09:30:00', NULL, 'backup_storage', 'assigned'),
(4, 3, 104, '2026-03-07 14:20:00', '2026-03-12 20:00:00', 'primary_compute', 'released'),
(5, 4, 105, '2026-03-05 10:00:00', '2026-03-08 16:30:00', 'monitoring', 'released'),
(6, 5, 106, '2026-03-18 09:00:00', NULL, 'gpu_compute', 'pending');

INSERT INTO deployment_priority_history (
    priorityHistoryId,
    deploymentId,
    priorityLevelId,
    startTime,
    endTime
) VALUES
(1, 1, 3, '2026-03-01 08:00:00', '2026-03-10 18:00:00'),
(2, 2, 2, '2026-03-02 09:30:00', NULL),
(3, 3, 4, '2026-03-03 07:00:00', '2026-03-12 20:00:00'),
(4, 4, 1, '2026-03-05 10:00:00', '2026-03-08 16:30:00'),
(5, 5, 3, '2026-03-18 09:00:00', NULL);

INSERT INTO deployment_event (
    eventId,
    deploymentId,
    eventType,
    eventTime,
    staffId,
    clientId,
    fromResourceId,
    toResourceId,
    oldValue,
    newValue,
    reason,
    note
) VALUES
(1, 1, 'created', '2026-03-01 08:00:00', 1, 1, NULL, NULL, 'requested', 'created', 'new deployment request accepted', 'Deployment record created by scheduler'),
(2, 1, 'started', '2026-03-01 08:15:00', 1, 1, NULL, NULL, 'planned', 'active', 'resources assigned and service started', 'Analytics cluster started successfully'),
(3, 2, 'scaled_up', '2026-03-04 11:00:00', 2, 2, NULL, NULL, '1 backup node', 'expanded backup allocation', 'client requested higher backup capacity', 'Capacity increased within same deployment'),
(4, 3, 'migrated', '2026-03-07 14:20:00', 3, 1, 101, 104, 'resource 101', 'resource 104', 'resource 101 entered maintenance window', 'Workload moved to replacement compute node'),
(5, 4, 'terminated', '2026-03-08 16:30:00', 2, 3, NULL, NULL, 'active', 'completed', 'test period ended normally', 'Internal test deployment finished'),
(6, 5, 'created', '2026-03-18 09:00:00', 1, 4, NULL, NULL, 'requested', 'planned', 'GPU deployment scheduled', 'Pending final resource confirmation');

INSERT INTO usage_record (
    usageRecordId,
    deploymentId,
    resourceId,
    usageType,
    quantity,
    startTime,
    endTime,
    unit,
    isFinal
) VALUES
(1, 1, 101, 'compute', 48, '2026-03-01 08:00:00', '2026-03-03 08:00:00', 'hours', 1),
(2, 1, 102, 'storage', 1200, '2026-03-01 08:00:00', '2026-03-10 18:00:00', 'GB', 1),
(3, 2, 103, 'backup', 800, '2026-03-02 09:30:00', '2026-03-06 09:30:00', 'GB', 0),
(4, 3, 104, 'compute', 72, '2026-03-07 14:20:00', '2026-03-10 14:20:00', 'hours', 1),
(5, 4, 105, 'monitoring', 78.5, '2026-03-05 10:00:00', '2026-03-08 16:30:00', 'hours', 1),
(6, 5, 106, 'compute', 24, '2026-03-18 09:00:00', '2026-03-19 09:00:00', 'hours', 0);

-- Billing
INSERT INTO paying_party (
    payingPartyId,
    clientId,
    partyName
) VALUES
(1, 1, 'Alice Chen Personal Account'),
(2, 2, 'Patel Backup Team Account'),
(3, 3, 'GreenLeaf Labs Billing Account'),
(4, 4, 'Sofia Rivera Personal Account');

INSERT INTO billing_address (
    addressId,
    payingPartyId,
    addressType,
    addressLine1,
    city,
    zipCode,
    country
) VALUES
(1, 1, 'billing', '12 Hudson St', 'Hoboken', '07030', 'USA'),
(2, 2, 'business', '85 Market Ave', 'Jersey City', '07302', 'USA'),
(3, 3, 'business', '400 Research Park Rd', 'Newark', '07102', 'USA'),
(4, 4, 'home', '73 West 14th St', 'New York', '10011', 'USA');

INSERT INTO payment_method (
    paymentMethodId,
    payingPartyId,
    bankAccountName,
    routingNumber,
    accountNumber
) VALUES
(1, 1, 'Alice Chen Checking', '021000021', '1000000001'),
(2, 2, 'Patel Team Operations', '026009593', '1000000002'),
(3, 3, 'GreenLeaf Labs AP', '111000025', '1000000003'),
(4, 4, 'Sofia Rivera Checking', '121000358', '1000000004');

INSERT INTO beneficiary (
    beneficiaryId,
    clientId,
    beneficiaryName
) VALUES
(1, 1, 'Alice Chen'),
(2, 2, 'Brian Patel Team'),
(3, 3, 'GreenLeaf Labs Operations'),
(4, 4, 'Sofia Rivera');

INSERT INTO beneficiary_paying_party (
    payingPartyId,
    beneficiaryId
) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4);

INSERT INTO bill_header (
    billId,
    payingPartyId,
    billStatus,
    issueDate,
    dueDate
) VALUES
(1, 1, 'pending', '2026-04-01 09:00:00', '2026-04-15 23:59:59'),
(2, 2, 'paid', '2026-04-01 09:00:00', '2026-04-15 23:59:59'),
(3, 3, 'paid', '2026-04-01 09:00:00', '2026-04-15 23:59:59'),
(4, 4, 'unpaid', '2026-04-02 09:00:00', '2026-04-16 23:59:59');

INSERT INTO bill_item (
    billItemId,
    billId,
    usageRecordId,
    beneficiaryId
) VALUES
(1, 1, 1, 1),
(2, 1, 2, 1),
(3, 2, 3, 2),
(4, 3, 5, 3),
(5, 4, 6, 4);

INSERT INTO payment (
    paymentId,
    billId,
    paymentMethodId,
    amountPaid,
    dateFulfilled
) VALUES
(1, 1, 1, 75.00, '2026-04-05 13:00:00'),
(2, 2, 2, 64.00, '2026-04-03 11:00:00'),
(3, 3, 3, 147.00, '2026-04-04 15:30:00'),
(4, 4, 4, 0.00, NULL);

INSERT INTO bill_adjustment (
    adjustmentId,
    billId,
    deposit,
    depositDueDate,
    accountCredit,
    refund,
    surcharge,
    emergencyFee,
    discount,
    approvedByStaffId,
    createdAt,
    adjustmentStatus
) VALUES
(1, 1, 50.00, '2026-04-05 00:00:00', 0.00, 0.00, 0.00, 50.00, 0.00, 4, '2026-04-01 10:00:00','active'),
(2, 2, 0.00, NULL, 5.00, 0.00, 0.00, 0.00, 0.00, 2, '2026-04-01 10:15:00','active'),
(3, 3, 0.00, NULL, 0.00, 0.00, 0.00, 0.00, 10.00, 1, '2026-04-01 10:30:00','active'),
(4, 4, 25.00, '2026-04-06 00:00:00', 0.00, 0.00, 5.00, 25.00, 0.00, 4, '2026-04-02 10:00:00','active');

INSERT INTO pricing (
    usageRecordId,
    unitPriceAtBilling
) VALUES
(1, 2.50),
(2, 0.08),
(3, 0.08),
(4, 2.75),
(5, 2.00),
(6, 6.50);

-- additional 4 months data for billing & related deployment tables

INSERT INTO beneficiary_paying_party (
    payingPartyId,
    beneficiaryId
) VALUES
(2, 1),
(3, 1),
(1, 4),
(4, 2);



INSERT INTO deployment_resource (
    deploymentResourceId,
    deploymentId,
    resourceId,
    assignedAt,
    releasedAt,
    roleInDeployment,
    assignmentStatus
) VALUES
(7, 6, 104, '2026-04-08 08:00:00', '2026-04-15 18:00:00', 'analytics_compute', 'released'),
(8, 7, 103, '2026-04-11 09:00:00', '2026-04-13 21:00:00', 'backup_storage', 'released'),
(9, 8, 101, '2026-05-02 08:00:00', '2026-05-18 18:00:00', 'training_compute', 'released'),
(10, 9, 104, '2026-05-10 06:00:00', '2026-05-20 20:00:00', 'fraud_detection', 'released'),
(11, 10, 106, '2026-06-01 08:00:00', NULL, 'gpu_compute', 'assigned'),
(12, 11, 103, '2026-06-14 10:00:00', '2026-06-16 22:00:00', 'emergency_backup', 'released'),
(13, 12, 104, '2026-04-01 08:00:00', NULL, 'monthly_analytics_compute', 'assigned'),
(14, 12, 102, '2026-04-01 08:00:00', NULL, 'analytics_storage', 'assigned'),
(15, 13, 103, '2026-04-01 09:00:00', NULL, 'recurring_backup', 'assigned'),
(16, 14, 106, '2026-04-15 08:00:00', NULL, 'long_term_gpu_compute', 'assigned'),
(17, 15, 105, '2026-04-01 00:00:00', '2026-07-31 23:59:59', 'monitoring', 'released'),
(18, 16, 105, '2026-05-01 00:00:00', NULL, 'support_monitoring', 'assigned');

INSERT INTO deployment_event (
    eventId,
    deploymentId,
    eventType,
    eventTime,
    staffId,
    clientId,
    fromResourceId,
    toResourceId,
    oldValue,
    newValue,
    reason,
    note
) VALUES
(7, 6, 'created', '2026-04-08 08:00:00', 1, 1, NULL, NULL, 'requested', 'created', 'monthly analytics refresh', 'Alice resumed analytics workloads'),
(8, 7, 'scaled_up', '2026-04-11 14:00:00', 2, 2, NULL, NULL, '2 TB', '5 TB', 'unexpected backup growth', 'Backup temporarily expanded'),
(9, 8, 'started', '2026-05-02 08:10:00', 1, 1, NULL, NULL, 'planned', 'active', 'training deployment launched', 'Monthly ML retraining started'),
(10, 9, 'migrated', '2026-05-15 12:00:00', 3, 1, 101, 104, 'compute node 101', 'compute node 104', 'maintenance balancing', 'Moved during high load'),
(11, 10, 'created', '2026-06-01 08:00:00', 1, 4, NULL, NULL, 'requested', 'active', 'GPU hosting approved', 'Long-term GPU workload'),
(12, 11, 'manual_adjustment', '2026-06-14 18:00:00', 4, 2, NULL, NULL, 'standard backup', 'priority backup', 'emergency support request', 'Backup reprioritized manually'),
(13, 12, 'created', '2026-04-01 08:00:00', 1, 1, NULL, NULL, 'requested', 'created', 'four month analytics agreement', 'Analytics retainer opened'),
(14, 12, 'scaled_up', '2026-05-01 10:00:00', 2, 1, NULL, NULL, 'baseline compute', 'expanded compute', 'May training workload', 'Compute hours increased'),
(15, 12, 'scaled_down', '2026-06-20 15:00:00', 2, 1, NULL, NULL, 'expanded compute', 'baseline compute', 'lower demand after model run', 'Compute allocation reduced'),
(16, 13, 'created', '2026-04-01 09:00:00', 2, 2, NULL, NULL, 'requested', 'active', 'recurring backup service', 'Backup retainer started'),
(17, 13, 'manual_adjustment', '2026-06-15 11:00:00', 4, 2, NULL, NULL, 'standard backup', 'priority backup', 'mid-month urgent backup', 'Emergency backup charge approved'),
(18, 14, 'created', '2026-04-15 08:00:00', 1, 4, NULL, NULL, 'requested', 'active', 'long term GPU hosting', 'GPU hosting opened'),
(19, 14, 'paused', '2026-07-03 09:00:00', 3, 4, NULL, NULL, 'active', 'paused', 'client maintenance window', 'GPU workload paused'),
(20, 14, 'resumed', '2026-07-08 09:00:00', 3, 4, NULL, NULL, 'paused', 'active', 'maintenance completed', 'GPU workload resumed'),
(21, 15, 'created', '2026-04-01 00:00:00', 2, 3, NULL, NULL, 'requested', 'active', 'four month monitoring', 'Monitoring retainer started'),
(22, 16, 'created', '2026-05-01 00:00:00', 3, 3, NULL, NULL, 'requested', 'active', 'support coverage requested', 'Support monitoring enabled');

INSERT INTO usage_record (
    usageRecordId,
    deploymentId,
    resourceId,
    usageType,
    quantity,
    startTime,
    endTime,
    unit,
    isFinal
) VALUES
(7, 6, 104, 'compute', 96, '2026-04-08 08:00:00', '2026-04-12 08:00:00', 'hours', 1),
(8, 7, 103, 'backup', 3200, '2026-04-11 09:00:00', '2026-04-13 21:00:00', 'GB', 1),
(9, 8, 101, 'compute', 220, '2026-05-02 08:00:00', '2026-05-18 18:00:00', 'hours', 1),
(10, 9, 104, 'compute', 180, '2026-05-10 06:00:00', '2026-05-20 20:00:00', 'hours', 1),
(11, 10, 106, 'compute', 240, '2026-06-01 08:00:00', '2026-06-11 08:00:00', 'hours', 0),
(12, 11, 103, 'backup', 5000, '2026-06-14 10:00:00', '2026-06-16 22:00:00', 'GB', 1),
(13, 12, 104, 'compute', 160, '2026-04-01 08:00:00', '2026-04-30 23:59:59', 'hours', 1),
(14, 12, 102, 'storage', 900, '2026-04-01 08:00:00', '2026-04-30 23:59:59', 'GB', 1),
(15, 12, 104, 'compute', 240, '2026-05-01 00:00:00', '2026-05-31 23:59:59', 'hours', 1),
(16, 12, 104, 'compute', 130, '2026-06-01 00:00:00', '2026-06-30 23:59:59', 'hours', 1),
(17, 12, 102, 'storage', 1200, '2026-07-01 00:00:00', '2026-07-31 23:59:59', 'GB', 1),
(18, 13, 103, 'backup', 2600, '2026-04-01 09:00:00', '2026-04-30 23:59:59', 'GB', 1),
(19, 13, 103, 'backup', 3100, '2026-05-01 00:00:00', '2026-05-31 23:59:59', 'GB', 1),
(20, 13, 103, 'backup', 4800, '2026-06-01 00:00:00', '2026-06-30 23:59:59', 'GB', 1),
(21, 13, 103, 'backup', 2800, '2026-07-01 00:00:00', '2026-07-31 23:59:59', 'GB', 1),
(22, 14, 106, 'compute', 300, '2026-04-15 08:00:00', '2026-04-30 23:59:59', 'hours', 1),
(23, 14, 106, 'compute', 420, '2026-05-01 00:00:00', '2026-05-31 23:59:59', 'hours', 1),
(24, 14, 106, 'compute', 390, '2026-06-01 00:00:00', '2026-06-30 23:59:59', 'hours', 1),
(25, 14, 106, 'compute', 210, '2026-07-01 00:00:00', '2026-07-31 23:59:59', 'hours', 1),
(26, 15, 105, 'monitoring', 720, '2026-04-01 00:00:00', '2026-04-30 23:59:59', 'hours', 1),
(27, 15, 105, 'monitoring', 744, '2026-05-01 00:00:00', '2026-05-31 23:59:59', 'hours', 1),
(28, 15, 105, 'monitoring', 720, '2026-06-01 00:00:00', '2026-06-30 23:59:59', 'hours', 1),
(29, 15, 105, 'monitoring', 744, '2026-07-01 00:00:00', '2026-07-31 23:59:59', 'hours', 1),
(30, 16, 105, 'support', 25, '2026-05-01 00:00:00', '2026-05-31 23:59:59', 'hours', 1),
(31, 16, 105, 'support', 40, '2026-06-01 00:00:00', '2026-06-30 23:59:59', 'hours', 1),
(32, 16, 105, 'support', 35, '2026-07-01 00:00:00', '2026-07-31 23:59:59', 'hours', 1);

INSERT INTO pricing (
    usageRecordId,
    unitPriceAtBilling
) VALUES
(7, 2.75),
(8, 0.10),
(9, 3.10),
(10, 2.95),
(11, 7.25),
(12, 0.12),
(13, 2.80),
(14, 0.08),
(15, 3.00),
(16, 2.90),
(17, 0.08),
(18, 0.10),
(19, 0.10),
(20, 0.13),
(21, 0.10),
(22, 7.25),
(23, 7.25),
(24, 7.50),
(25, 7.75),
(26, 1.75),
(27, 1.75),
(28, 1.80),
(29, 1.80),
(30, 4.00),
(31, 4.25),
(32, 4.25);

INSERT INTO bill_header (
    billId,
    payingPartyId,
    billStatus,
    issueDate,
    dueDate
) VALUES
(5, 2, 'paid', '2026-04-20 09:00:00', '2026-05-05 23:59:59'),
(6, 2, 'pending', '2026-05-20 09:00:00', '2026-06-05 23:59:59'),
(7, 3, 'paid', '2026-05-25 09:00:00', '2026-06-10 23:59:59'),
(8, 1, 'overdue', '2026-06-15 09:00:00', '2026-06-30 23:59:59'),
(9, 4, 'unpaid', '2026-06-20 09:00:00', '2026-07-05 23:59:59'),
(10, 2, 'paid', '2026-05-01 09:00:00', '2026-05-15 23:59:59'),
(11, 2, 'paid', '2026-06-01 09:00:00', '2026-06-15 23:59:59'),
(12, 2, 'pending', '2026-07-01 09:00:00', '2026-07-15 23:59:59'),
(13, 4, 'paid', '2026-05-01 09:00:00', '2026-05-15 23:59:59'),
(14, 4, 'paid', '2026-06-01 09:00:00', '2026-06-15 23:59:59'),
(15, 4, 'unpaid', '2026-07-01 09:00:00', '2026-07-15 23:59:59'),
(16, 3, 'paid', '2026-05-01 09:00:00', '2026-05-15 23:59:59'),
(17, 3, 'paid', '2026-06-01 09:00:00', '2026-06-15 23:59:59'),
(18, 3, 'pending', '2026-07-01 09:00:00', '2026-07-15 23:59:59');

INSERT INTO bill_item (
    billItemId,
    billId,
    usageRecordId,
    beneficiaryId
) VALUES
(6, 5, 7, 1),
(7, 5, 8, 1),
(8, 6, 9, 1),
(9, 7, 10, 3),
(10, 8, 11, 4),
(11, 9, 12, 2),
(12, 10, 13, 1),
(13, 10, 14, 1),
(14, 11, 15, 1),
(15, 11, 16, 1),
(16, 12, 17, 1),
(17, 12, 21, 2),
(18, 13, 22, 4),
(19, 13, 18, 2),
(20, 14, 23, 4),
(21, 14, 19, 2),
(22, 15, 24, 4),
(23, 15, 25, 4),
(24, 16, 26, 3),
(25, 16, 30, 3),
(26, 17, 27, 3),
(27, 17, 31, 3),
(28, 18, 28, 3),
(29, 18, 29, 3),
(30, 18, 32, 3);

INSERT INTO payment (
    paymentId,
    billId,
    paymentMethodId,
    amountPaid,
    dateFulfilled
) VALUES
(5, 5, 2, 584.00, '2026-04-28 10:00:00'),
(6, 7, 3, 510.00, '2026-05-28 11:00:00'),
(7, 8, 1, 150.00, '2026-06-18 12:00:00'),
(8, 10, 2, 575.00, '2026-05-07 10:00:00'),
(9, 11, 2, 1150.00, '2026-06-07 10:00:00'),
(10, 13, 4, 2175.00, '2026-05-08 12:00:00'),
(11, 14, 4, 3150.00, '2026-06-08 12:00:00'),
(12, 16, 3, 1370.00, '2026-05-06 11:00:00'),
(13, 17, 3, 1470.00, '2026-06-06 11:00:00');

INSERT INTO bill_adjustment (
    adjustmentId,
    billId,
    deposit,
    depositDueDate,
    accountCredit,
    refund,
    surcharge,
    emergencyFee,
    discount,
    approvedByStaffId,
    createdAt,
    adjustmentStatus
) VALUES
(5, 5, 0, NULL, 15, 0, 20, 0, 0, 4, '2026-04-20 10:00:00', 'inactive'),
(6, 5, 0, NULL, 15, 0, 10, 0, 5, 4, '2026-04-21 09:00:00', 'active'),
(7, 6, 50, '2026-05-25 00:00:00', 0, 0, 0, 25, 0, 4, '2026-05-20 12:00:00', 'active'),
(8, 7, 0, NULL, 0, 20, 0, 0, 15, 2, '2026-05-25 13:00:00', 'active'),
(9, 8, 100, '2026-06-18 00:00:00', 0, 0, 40, 50, 0, 4, '2026-06-15 09:00:00', 'active'),
(10, 9, 0, NULL, 25, 0, 60, 0, 0, 2, '2026-06-20 14:00:00', 'active'),
(11, 10, 0, NULL, 20, 0, 0, 0, 10, 4, '2026-05-01 10:00:00', 'active'),
(12, 11, 0, NULL, 0, 0, 25, 0, 0, 4, '2026-06-01 10:00:00', 'active'),
(13, 12, 0, NULL, 0, 0, 15, 40, 0, 2, '2026-07-01 10:00:00', 'active'),
(14, 13, 100, '2026-05-05 00:00:00', 0, 0, 0, 0, 0, 4, '2026-05-01 10:30:00', 'active'),
(15, 14, 0, NULL, 30, 0, 0, 0, 0, 4, '2026-06-01 10:30:00', 'active'),
(16, 15, 0, NULL, 0, 0, 25, 75, 20, 4, '2026-07-01 10:30:00', 'active'),
(17, 16, 0, NULL, 0, 0, 0, 0, 25, 2, '2026-05-01 11:00:00', 'active'),
(18, 17, 0, NULL, 10, 0, 0, 0, 0, 2, '2026-06-01 11:00:00', 'active'),
(19, 18, 0, NULL, 0, 0, 40, 0, 0, 4, '2026-07-01 11:00:00', 'active');
