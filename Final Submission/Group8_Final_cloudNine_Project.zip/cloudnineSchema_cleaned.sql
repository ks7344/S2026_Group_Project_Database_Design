PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS pricing;
DROP TABLE IF EXISTS bill_adjustment;
DROP TABLE IF EXISTS payment;
DROP TABLE IF EXISTS bill_item;
DROP TABLE IF EXISTS bill_header;
DROP TABLE IF EXISTS beneficiary_paying_party;
DROP TABLE IF EXISTS beneficiary;
DROP TABLE IF EXISTS payment_method;
DROP TABLE IF EXISTS billing_address;
DROP TABLE IF EXISTS paying_party;

DROP TABLE IF EXISTS usage_record;
DROP TABLE IF EXISTS deployment_event;
DROP TABLE IF EXISTS deployment_priority_history;
DROP TABLE IF EXISTS deployment_resource;
DROP TABLE IF EXISTS deployment;
DROP TABLE IF EXISTS priority_level;
DROP TABLE IF EXISTS deployment_status;

DROP TABLE IF EXISTS actual_assignment;
DROP TABLE IF EXISTS need;
DROP TABLE IF EXISTS reservation;

DROP TABLE IF EXISTS resource_availability_event;
DROP TABLE IF EXISTS resource_capacity;
DROP TABLE IF EXISTS resource;
DROP TABLE IF EXISTS resource_type;
DROP TABLE IF EXISTS availability_zone;
DROP TABLE IF EXISTS data_center;
DROP TABLE IF EXISTS cloud_region;

DROP TABLE IF EXISTS staff;
DROP TABLE IF EXISTS client;

-- CloudNine database schema
-- Final clean ERD-consistent version based on the three ERD sections provided.

-- Client & Staff
CREATE TABLE client (
    clientId INTEGER PRIMARY KEY,
    firstName TEXT NOT NULL,
    lastName TEXT NOT NULL,
    whatFor TEXT,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    phoneNumber TEXT,
    clientType TEXT NOT NULL CHECK (clientType IN ('individual', 'group', 'organization'))
);

CREATE TABLE staff (
    staffId INTEGER PRIMARY KEY,
    firstName TEXT NOT NULL,
    lastName TEXT NOT NULL,
    jobType TEXT NOT NULL
);

-- Infrastructure
CREATE TABLE cloud_region (
    regionId INTEGER PRIMARY KEY,
    cloudRegionName TEXT NOT NULL UNIQUE
);

CREATE TABLE data_center (
    dataCenterId INTEGER PRIMARY KEY,
    cloudRegionId INTEGER NOT NULL,
    dataCenterName TEXT NOT NULL,
    FOREIGN KEY (cloudRegionId) REFERENCES cloud_region(regionId)
);

CREATE TABLE availability_zone (
    zoneId INTEGER PRIMARY KEY,
    dataCenterId INTEGER NOT NULL,
    zoneName TEXT NOT NULL,
    zoneStatus TEXT NOT NULL CHECK (zoneStatus IN ('active', 'degraded', 'offline')),
    FOREIGN KEY (dataCenterId) REFERENCES data_center(dataCenterId)
);

CREATE TABLE resource_type (
    resourceTypeId INTEGER PRIMARY KEY,
    typeName TEXT NOT NULL UNIQUE,
    performanceTier TEXT NOT NULL,
    capacityRating TEXT
);

CREATE TABLE resource (
    resourceId INTEGER PRIMARY KEY,
    resourceTypeId INTEGER NOT NULL,
    zoneId INTEGER NOT NULL,
    resourceLabel TEXT NOT NULL UNIQUE,
    currentStatus TEXT NOT NULL CHECK (currentStatus IN ('available', 'in_use', 'maintenance', 'retired')),
    FOREIGN KEY (resourceTypeId) REFERENCES resource_type(resourceTypeId),
    FOREIGN KEY (zoneId) REFERENCES availability_zone(zoneId)
);

CREATE TABLE resource_capacity (
    capacityId INTEGER PRIMARY KEY,
    resourceId INTEGER NOT NULL,
    capacityName TEXT NOT NULL,
    capacityValue REAL NOT NULL CHECK (capacityValue >= 0),
    capacityUnit TEXT NOT NULL,
    FOREIGN KEY (resourceId) REFERENCES resource(resourceId)
);

CREATE TABLE resource_availability_event (
    availabilityEventId INTEGER PRIMARY KEY,
    resourceId INTEGER NOT NULL,
    eventType TEXT NOT NULL CHECK (eventType IN ('maintenance', 'outage', 'repair')),
    startTime TEXT NOT NULL,
    endTime TEXT,
    note TEXT,
    FOREIGN KEY (resourceId) REFERENCES resource(resourceId),
    CHECK (endTime IS NULL OR startTime < endTime)
);

-- Reservation & Scheduling
CREATE TABLE reservation (
    reservationId INTEGER PRIMARY KEY,
    clientId INTEGER NOT NULL,
    staffId INTEGER NOT NULL,
    regionId INTEGER,
    requestStartTime TEXT NOT NULL,
    requestEndTime TEXT NOT NULL,
    reservationType TEXT NOT NULL,
    status TEXT NOT NULL,
    emergencyLevel INTEGER NOT NULL DEFAULT 1 CHECK (emergencyLevel BETWEEN 1 AND 5),
    FOREIGN KEY (clientId) REFERENCES client(clientId),
    FOREIGN KEY (staffId) REFERENCES staff(staffId),
    FOREIGN KEY (regionId) REFERENCES cloud_region(regionId),
    CHECK (requestStartTime < requestEndTime)
);

CREATE TABLE need (
    needId INTEGER PRIMARY KEY,
    reservationId INTEGER NOT NULL,
    resourceTypeId INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    capacityRequirement TEXT,
    flexibilityLevel TEXT NOT NULL CHECK (flexibilityLevel IN ('strict', 'flexible')),
    note TEXT,
    FOREIGN KEY (reservationId) REFERENCES reservation(reservationId),
    FOREIGN KEY (resourceTypeId) REFERENCES resource_type(resourceTypeId)
);

CREATE TABLE actual_assignment (
    assignmentId INTEGER PRIMARY KEY,
    reservationId INTEGER NOT NULL,
    regionId INTEGER NOT NULL,
    eventStartTime TEXT NOT NULL,
    eventEndTime TEXT,
    satisfactionScore INTEGER CHECK (satisfactionScore BETWEEN 1 AND 5),
    reason TEXT,
    FOREIGN KEY (reservationId) REFERENCES reservation(reservationId),
    FOREIGN KEY (regionId) REFERENCES cloud_region(regionId),
    CHECK (eventEndTime IS NULL OR eventStartTime < eventEndTime)
);

-- Deployment & Usage
CREATE TABLE deployment_status (
    statusId INTEGER PRIMARY KEY,
    statusName TEXT NOT NULL UNIQUE
);

CREATE TABLE priority_level (
    priorityLevelId INTEGER PRIMARY KEY,
    priorityName TEXT NOT NULL UNIQUE,
    rankValue INTEGER NOT NULL UNIQUE CHECK (rankValue >= 1)
);

CREATE TABLE deployment (
    deploymentId INTEGER PRIMARY KEY,
    reservationId INTEGER NOT NULL,
    statusId INTEGER NOT NULL,
    deploymentName TEXT NOT NULL,
    startTime TEXT NOT NULL,
    endTime TEXT,
    FOREIGN KEY (reservationId) REFERENCES reservation(reservationId),
    FOREIGN KEY (statusId) REFERENCES deployment_status(statusId),
    CHECK (endTime IS NULL OR endTime >= startTime)
);

CREATE TABLE deployment_resource (
    deploymentResourceId INTEGER PRIMARY KEY,
    deploymentId INTEGER NOT NULL,
    resourceId INTEGER NOT NULL,
    assignedAt TEXT NOT NULL,
    releasedAt TEXT,
    roleInDeployment TEXT,
    assignmentStatus TEXT CHECK (assignmentStatus IN ('assigned', 'released', 'pending')),
    FOREIGN KEY (deploymentId) REFERENCES deployment(deploymentId),
    FOREIGN KEY (resourceId) REFERENCES resource(resourceId),
    CHECK (releasedAt IS NULL OR releasedAt >= assignedAt)
);

CREATE TABLE deployment_priority_history (
    priorityHistoryId INTEGER PRIMARY KEY,
    deploymentId INTEGER NOT NULL,
    priorityLevelId INTEGER NOT NULL,
    startTime TEXT NOT NULL,
    endTime TEXT,
    FOREIGN KEY (deploymentId) REFERENCES deployment(deploymentId),
    FOREIGN KEY (priorityLevelId) REFERENCES priority_level(priorityLevelId),
    CHECK (endTime IS NULL OR startTime < endTime)
);

CREATE TABLE deployment_event (
    eventId INTEGER PRIMARY KEY,
    deploymentId INTEGER NOT NULL,
    eventType TEXT NOT NULL CHECK (
        eventType IN (
            'created',
            'started',
            'paused',
            'resumed',
            'scaled_up',
            'scaled_down',
            'migrated',
            'terminated',
            'reassigned',
            'manual_adjustment'
        )
    ),
    eventTime TEXT NOT NULL,
    staffId INTEGER,
    clientId INTEGER,
    fromResourceId INTEGER,
    toResourceId INTEGER,
    oldValue TEXT,
    newValue TEXT,
    reason TEXT,
    note TEXT,
    FOREIGN KEY (deploymentId) REFERENCES deployment(deploymentId),
    FOREIGN KEY (staffId) REFERENCES staff(staffId),
    FOREIGN KEY (clientId) REFERENCES client(clientId),
    FOREIGN KEY (fromResourceId) REFERENCES resource(resourceId),
    FOREIGN KEY (toResourceId) REFERENCES resource(resourceId),
    CHECK (fromResourceId IS NULL OR toResourceId IS NULL OR fromResourceId <> toResourceId)
);

CREATE TABLE usage_record (
    usageRecordId INTEGER PRIMARY KEY,
    deploymentId INTEGER NOT NULL,
    resourceId INTEGER NOT NULL,
    usageType TEXT NOT NULL CHECK (
        usageType IN ('compute', 'storage', 'network', 'support', 'backup', 'monitoring')
    ),
    quantity REAL NOT NULL CHECK (quantity >= 0),
    startTime TEXT NOT NULL,
    endTime TEXT NOT NULL,
    unit TEXT NOT NULL,
    isFinal INTEGER NOT NULL DEFAULT 1 CHECK (isFinal IN (0, 1)),
    FOREIGN KEY (deploymentId) REFERENCES deployment(deploymentId),
    FOREIGN KEY (resourceId) REFERENCES resource(resourceId),
    CHECK (startTime < endTime)
);

-- Billing
CREATE TABLE paying_party (
    payingPartyId INTEGER PRIMARY KEY,
    clientId INTEGER NOT NULL,
    partyName TEXT NOT NULL,
    FOREIGN KEY (clientId) REFERENCES client(clientId)
);

CREATE TABLE billing_address (
    addressId INTEGER PRIMARY KEY,
    payingPartyId INTEGER NOT NULL,
    addressType TEXT NOT NULL CHECK (addressType IN ('billing', 'mailing', 'shipping', 'business', 'home')),
    addressLine1 TEXT NOT NULL,
    city TEXT NOT NULL,
    zipCode TEXT NOT NULL,
    country TEXT NOT NULL,
    FOREIGN KEY (payingPartyId) REFERENCES paying_party(payingPartyId)
);

CREATE TABLE payment_method (
    paymentMethodId INTEGER PRIMARY KEY,
    payingPartyId INTEGER NOT NULL,
    bankAccountName TEXT,
    routingNumber TEXT NOT NULL,
    accountNumber TEXT NOT NULL,
    FOREIGN KEY (payingPartyId) REFERENCES paying_party(payingPartyId)
);

CREATE TABLE beneficiary (
    beneficiaryId INTEGER PRIMARY KEY,
    clientId INTEGER NOT NULL,
    beneficiaryName TEXT NOT NULL,
    FOREIGN KEY (clientId) REFERENCES client(clientId)
);

CREATE TABLE beneficiary_paying_party (
    payingPartyId INTEGER NOT NULL,
    beneficiaryId INTEGER NOT NULL,
    PRIMARY KEY (payingPartyId, beneficiaryId),
    FOREIGN KEY (payingPartyId) REFERENCES paying_party(payingPartyId),
    FOREIGN KEY (beneficiaryId) REFERENCES beneficiary(beneficiaryId)
);

CREATE TABLE bill_header (
    billId INTEGER PRIMARY KEY,
    payingPartyId INTEGER NOT NULL,
    billStatus TEXT CHECK (billStatus IN ('unpaid', 'paid', 'pending', 'overdue')),
    issueDate TEXT,
    dueDate TEXT,
    FOREIGN KEY (payingPartyId) REFERENCES paying_party(payingPartyId)
);

CREATE TABLE bill_item (
    billItemId INTEGER PRIMARY KEY,
    billId INTEGER NOT NULL,
    usageRecordId INTEGER NOT NULL,
    beneficiaryId INTEGER NOT NULL,
    FOREIGN KEY (billId) REFERENCES bill_header(billId),
    FOREIGN KEY (usageRecordId) REFERENCES usage_record(usageRecordId),
    FOREIGN KEY (beneficiaryId) REFERENCES beneficiary(beneficiaryId)
);

CREATE TABLE payment (
    paymentId INTEGER PRIMARY KEY,
    billId INTEGER NOT NULL,
    paymentMethodId INTEGER NOT NULL,
    amountPaid NUMERIC NOT NULL CHECK (amountPaid >= 0),
    dateFulfilled TEXT,
    FOREIGN KEY (billId) REFERENCES bill_header(billId),
    FOREIGN KEY (paymentMethodId) REFERENCES payment_method(paymentMethodId)
);

CREATE TABLE bill_adjustment (
    adjustmentId INTEGER PRIMARY KEY,
    billId INTEGER NOT NULL,
    deposit NUMERIC DEFAULT 0 CHECK (deposit >= 0),
    depositDueDate TEXT,
    accountCredit NUMERIC DEFAULT 0 CHECK (accountCredit >= 0),
    refund NUMERIC DEFAULT 0 CHECK (refund >= 0),
    surcharge NUMERIC DEFAULT 0 CHECK (surcharge >= 0),
    emergencyFee NUMERIC DEFAULT 0 CHECK (emergencyFee >= 0),
    discount NUMERIC DEFAULT 0 CHECK (discount >= 0),
    approvedByStaffId INTEGER,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    adjustmentStatus TEXT CHECK (adjustmentStatus IN ('active', 'inactive')),
    FOREIGN KEY (billId) REFERENCES bill_header(billId),
    FOREIGN KEY (approvedByStaffId) REFERENCES staff(staffId)
);

CREATE TABLE pricing (
    usageRecordId INTEGER PRIMARY KEY,
    unitPriceAtBilling NUMERIC NOT NULL CHECK (unitPriceAtBilling >= 0),
    FOREIGN KEY (usageRecordId) REFERENCES usage_record(usageRecordId)
);
